<?php
// HTTP
define('HTTP_SERVER', 'http://192.168.2.105:85/arex/');
// HTTPS
define('HTTPS_SERVER', 'http://192.168.2.105:85/arex/');
// DIR
define('DIR_APPLICATION', 'C:/Websites/arex/');
define('DIR_SYSTEM', 'C:/Websites/arex/system/');
define('DIR_IMAGE', 'C:/Websites/arex/view/image/');
define('DIR_STORAGE', 'C:/Websites/arex/system/storage/');
define('DIR_TEMPLATE', DIR_APPLICATION . 'view/template/');
define('DIR_CONFIG', DIR_SYSTEM . 'config/');
define('DIR_CACHE', DIR_STORAGE . 'cache/');
define('DIR_LOGS', DIR_STORAGE . 'logs/');
define('DIR_UPLOAD', DIR_STORAGE . 'upload/');
// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '03.08.1998');
define('DB_DATABASE', 'arex');
define('DB_PORT', '3353');
define('DB_PREFIX', '');

