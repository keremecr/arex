<?php
$data['home_page']          = "Home";
$data['menu_news']          = "News";
$data['menu_contact1']      = "Contact Us";
$data['menu_contact2']      = "TOY - KOOP CONTACT";
$data['menu_contact3']      = "Please contact us to get detailed information about our cooperative and our projects. You can also start an e-newsletter subscription so that you can follow the latest developments related to our projects and our Cooperative.";
$data['menu_aboutus']       = "About Us";
$data['latest_news']        = "Last <span>News</span>";
$data['text_project']       = "Project <span>Squares</span>";
$data['text_project_text']  = "You can review the featured images of our project below. For all images, visit our gallery page.";
$data['text_news_detail']   = "We are pleased to share the developments regarding our cooperative and our projects with you.";
$data['text_tel']           = "Tel";
$data['text_fax']           = "Fax";
$data['text_email']         = "E-Mail";
$data['text_address']       = "Address";
$data['text_contact_form']  = "Contact Form";
$data['text_name_surname']  = "Fullname";
$data['text_message']       = "Enter your message ..";
$data['text_send']          = "Send";
$data['text_no_post']       = "There is no content in this category yet";
$data['text_categories']    = "Categories";
$data['text_pages']         = "Pages";
$data['text_contecnts']     = "Contents";
$data['text_more']          = "Read more";
$data['text_email_success'] = "The information has been successfully sent. Thank you.";
$data['text_email_error']   = "Something went wrong. Please try again.";





$data['text_moreoku']  = "READ MORE";
$data['text_galsel']   = "Selections From The Gallery";
$data['text_galgoz']   = "BROWSE GALLERY";
$data['text_birsor']   = "Do you have a question?";
$data['text_bizmail']  = "Send us an e-mail";
$data['text_whowhy']   = "Why U.S?";
$data['text_1']        = "Our commitment to quality and principles enables us to do long-term business with our customers.";
$data['text_prosol']   = "Professional Solutions";
$data['text_2']        = "ARS Shipping Turkey from all over the world as well as from all over the world to make Turkey international transportation.";
$data['text_uprice']   = "Affordable Prices";
$data['text_3']        = "Thanks to the contracts we have made with shipowners, we provide our customers with the most affordable cost advantage.";
$data['text_fasttes']  = "Fast Delivery";
$data['text_4']        = "ARS Shipping is performing a quick and safe delivery on Turkey and all over the world with extensive logistics network.";
$data['text_happycus'] = "Happy Customers";
$data['text_5']        = "ARS Shipping is an organization that keeps customer satisfaction at the highest level with years of experience and attaches great importance to this.";
$data['text_conthiz']  = "Fast Communication";
$data['text_hiztal']   = "Service Request Form";
$data['text_firmad']   = "Company Name";

















$data['text_online']         = "Online Transactions";
$data['text_kurumsal_takip'] = "Corporate Tracking";
$data['text_sube_girisi'] = "Branch Login";
$data['text_gonderi_sorgula'] = "Online Shipment Inquiry";
$data['text_gonderi_no'] = "Enter Shipment No..";
$data['menu_contact']       = "Contact";
$data['text_karayolu'] = "Road Freight";
$data['text_havayolu'] = "Air Freight";
$data['text_denizyolu'] = "Sea Freight";
$data['text_paketdepo'] = "Packaging & Storage"; 
$data['text_topteslim']     = "Total Delivery";
$data['text_dunyamus']     = "Dünya Çapında Müşteriler";
$data['text_araclar']     = "Owned Vehicles";
$data['text_ekipkisi']     = "People in the Team"; 
$data['text_cozortak']     = "Our Partners";
$data['text_biziozel'] = "What Makes Us Special";
$data['text_bozelmsg'] = "We carefully check the cargo we receive so that parcels, parcels, baskets, sacks can be transported undamaged. If the packaging is not suitable, we warn you to repackage it. In order to make your life easier, especially your documents and files in packaging We provide free \"file bag\" service to carry.";
$data['text_ambadepo'] = "Packaging<br>Service";
$data['text_degeserv'] = "Storage<br>Service ";
$data['text_yurtitas'] = "Domestic<br>Transport";
$data['text_yurtdtas'] = "Overseas<br>Transport";
$data['text_bizimile'] = "Contact Us"; 
$data['text_calisaat'] = "Working Hours";
$data['text_allright'] = "All Rights Reserved";
$data['text_soruhala'] = "Still Can't Find Answers To Your Questions?";

