<?php
class Language {
	private $default = 'en-gb';
	private $directory;
	public $data = array();
	
	public function __construct($directory = '') {
		$this->directory = $directory;
	}
	
	public function get($key) {
		return (isset($this->data[$key]) ? $this->data[$key] : $key);
	}
	
	public function set($key, $value) {
		$this->data[$key] = $value;
	}
	
	public function all() {
		return $this->data;
	}
	
	public function load($filename, $key = '') {
		if (!$key) {
			$_ = array();
	
			$file = "";
	
			if (is_file($file)) {
				require($file);
			}
	
			$file = "";
			
			if (is_file($file)) {
				require($file);
			} 
	
			$this->data = array_merge($this->data, $_);
		} else {
			// Put the language into a sub key
			$this->data[$key] = new Language($this->directory);
			$this->data[$key]->load($filename);
		}
		
		return $this->data;
	}
}