<?php
final class Loader {
	protected $registry;

	public function __construct($registry) {
		$this->registry = $registry;
	}
	
	public function controller($rota, $data = array()) {
		// Sanitize the call
		$rota = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota);
		
		// Keep the original trigger
		$trigger = $rota;
		
		// Trigger the pre events
		$result = $this->registry->get('event')->trigger('controller/' . $trigger . '/before', array(&$rota, &$data));
		
		// Make sure its only the last event that returns an output if required.
		if ($result != null && !$result instanceof Exception) {
			$output = $result;
		} else {
			$action = new Action($rota);
			$output = $action->execute($this->registry, array(&$data));
		}
		
		// Trigger the post events
		$result = $this->registry->get('event')->trigger('controller/' . $trigger . '/after', array(&$rota, &$data, &$output));
		
		if ($result && !$result instanceof Exception) {
			$output = $result;
		}

		if (!$output instanceof Exception) {
			return $output;
		}
	}

	public function model($rota) {
		// Sanitize the call
		$rota = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota);
		
		if (!$this->registry->has('model_' . str_replace('/', '_', $rota))) {
			$file  = DIR_APPLICATION . 'model/' . $rota . '.php';
			$class = 'Model' . preg_replace('/[^a-zA-Z0-9]/', '', $rota);
			
			if (is_file($file)) {
				include_once($file);
	
				$proxy = new Proxy();
				
				// Overriding models is a little harder so we have to use PHP's magic methods
				// In future version we can use runkit
				foreach (get_class_methods($class) as $method) {
					$proxy->{$method} = $this->callback($this->registry, $rota . '/' . $method);
					
				}
				$this->registry->set('model_' . str_replace('/', '_', (string)$rota), $proxy);
			} else {
				throw new \Exception('Error: Could not load model ' . $rota . '!');
			}
		}
	}

	public function view($rota, $data = array()) {
		// Sanitize the call
		$rota = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota);
		
		// Keep the original trigger
		$trigger = $rota;
		
		// Template contents. Not the output!
		$template = '';
		
		// Trigger the pre events
		$result = $this->registry->get('event')->trigger('view/' . $trigger . '/before', array(&$rota, &$data, &$template));
		
		// Make sure its only the last event that returns an output if required.
		if ($result && !$result instanceof Exception) {
			$output = $result;
		} else {
			$template = new Template($this->registry->get('config')->get('template_engine'));
				
			foreach ($data as $key => $value) {
				$template->set($key, $value);
			}

			$output = $template->render($this->registry->get('config')->get('template_directory') . $rota, $this->registry->get('config')->get('template_cache'));		
		}
		
		// Trigger the post events
		$result = $this->registry->get('event')->trigger('view/' . $trigger . '/after', array(&$rota, &$data, &$output));
		
		if ($result && !$result instanceof Exception) {
			$output = $result;
		}
		
		return $output;
	}

	public function library($rota) {
		// Sanitize the call
		$rota = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota);
			
		$file = DIR_SYSTEM . 'library/' . $rota . '.php';
		$class = str_replace('/', '\\', $rota);

		if (is_file($file)) {
			include_once($file);

			$this->registry->set(basename($rota), new $class($this->registry));
		} else {
			throw new \Exception('Error: Could not load library ' . $rota . '!');
		}
	}
	
	public function helper($rota) {
		$file = DIR_SYSTEM . 'helper/' . preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota) . '.php';

		if (is_file($file)) {
			include_once($file);
		} else {
			throw new \Exception('Error: Could not load helper ' . $rota . '!');
		}
	}

	public function config($rota) {
		$this->registry->get('event')->trigger('config/' . $rota . '/before', array(&$rota));
		
		$this->registry->get('config')->load($rota);
		
		$this->registry->get('event')->trigger('config/' . $rota . '/after', array(&$rota));
	}

	public function language($rota, $key = '') {
		// Sanitize the call
		$rota = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota);
		
		// Keep the original trigger
		$trigger = $rota;
				
		$result = $this->registry->get('event')->trigger('language/' . $trigger . '/before', array(&$rota, &$key));
		
		if ($result && !$result instanceof Exception) {
			$output = $result;
		} else {
			$output = $this->registry->get('language')->load($rota, $key);
		}
		
		$result = $this->registry->get('event')->trigger('language/' . $trigger . '/after', array(&$rota, &$key, &$output));
		
		if ($result && !$result instanceof Exception) {
			$output = $result;
		}
				
		return $output;
	}
	
	protected function callback($registry, $rota) {
		return function($args) use($registry, $rota) {
			static $model;
			
			$rota = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota);

			// Keep the original trigger
			$trigger = $rota;
					
			// Trigger the pre events
			$result = $registry->get('event')->trigger('model/' . $trigger . '/before', array(&$rota, &$args));
			
			if ($result && !$result instanceof Exception) {
				$output = $result;
			} else {
				$class = 'Model' . preg_replace('/[^a-zA-Z0-9]/', '', substr($rota, 0, strrpos($rota, '/')));
				
				// Store the model object
				$key = substr($rota, 0, strrpos($rota, '/'));
				
				if (!isset($model[$key])) {
					$model[$key] = new $class($registry);
				}
				
				$method = substr($rota, strrpos($rota, '/') + 1);
				
				$callable = array($model[$key], $method);
	
				if (is_callable($callable)) {
					$output = call_user_func_array($callable, $args);
				} else {
					throw new \Exception('Error: Could not call model/' . $rota . '!');
				}					
			}
			
			// Trigger the post events
			$result = $registry->get('event')->trigger('model/' . $trigger . '/after', array(&$rota, &$args, &$output));
			
			if ($result && !$result instanceof Exception) {
				$output = $result;
			}
						
			return $output;
		};
	}	
}