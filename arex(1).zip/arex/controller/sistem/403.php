<?php
class ControllerSistem403 extends Controller {
	public function index() {

		$this->document->setTitle("Erişim İzniniz Yok!");

		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');

		$this->response->setOutput($this->load->view('sistem/403', $data));
	}
}
