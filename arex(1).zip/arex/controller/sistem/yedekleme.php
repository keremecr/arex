<?php
class ControllerSistemYedekleme extends Controller {
	public function index() {
		$this->document->setTitle("Yedekle & Geri Yükle");

		if (isset($this->session->data['error'])) {
			$data['error_warning'] = $this->session->data['error'];
			unset($this->session->data['error']);
		} else {
			$data['error_warning'] = '';
		}

		$data['token'] = $this->session->data['token'];
		$data['export'] = $this->url->link('sistem/yedekleme/export', 'token=' . $this->session->data['token'], true);
		$this->load->model('tool/backup');

		$data['tables'] = $this->model_tool_backup->getTables();

		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');

		$this->response->setOutput($this->load->view('sistem/yedekleme', $data));
	}
	
	public function import() {		
		$json = array();
		if (!$this->user->hasPermission('modify', 'sistem/yedekleme')) {
			$json['error'] = "Yedekleme &amp; Geri Yüklemeleri düzenleme iznine sahip değilsiniz!";
		}
		if (isset($this->request->files['import']['tmp_name']) && is_uploaded_file($this->request->files['import']['tmp_name'])) {
			$filename = tempnam(DIR_UPLOAD, 'bac');
			move_uploaded_file($this->request->files['import']['tmp_name'], $filename);
		} elseif (isset($this->request->get['import'])) {
			$filename = html_entity_decode($this->request->get['import'], ENT_QUOTES, 'UTF-8');
		} else {
			$filename = '';
		}
		if (!is_file($filename)) {
			$json['error'] = "Hatalı dosya!";
		}	
		if (isset($this->request->get['position'])) {
			$position = $this->request->get['position'];
		} else {
			$position = 0; 	
		}		
		if (!$json) {
			// We set $i so we can batch execute the queries rather than do them all at once.
			$i = 0;
			$start = false;
			$handle = fopen($filename, 'r');
			fseek($handle, $position, SEEK_SET);
			while (!feof($handle) && ($i < 100)) {
				$position = ftell($handle);
				$line = fgets($handle, 1000000);
				if (substr($line, 0, 14) == 'TRUNCATE TABLE' || substr($line, 0, 11) == 'INSERT INTO') {
					$sql = '';
					$start = true;
				}
				if ($i > 0 && (substr($line, 0, 24) == 'TRUNCATE TABLE `oc_user`' || substr($line, 0, 30) == 'TRUNCATE TABLE `oc_user_group`')) {
					fseek($handle, $position, SEEK_SET);
					break;
				}
				if ($start) {
					$sql .= $line;
				}
				if ($start && substr($line, -2) == ";\n") {
					$this->db->query(substr($sql, 0, strlen($sql) -2));
					$start = false;
				}	
				$i++;
			}
			$position = ftell($handle);
			$size = filesize($filename);
			$json['total'] = round(($position / $size) * 100);
			if ($position && !feof($handle)) {
				$json['next'] = str_replace('&amp;', '&', $this->url->link('sistem/yedekleme/import', 'token=' . $this->session->data['token'] . '&import=' . $filename . '&position=' . $position, true));
				fclose($handle);
			} else {
				fclose($handle);
				unlink($filename);
				$json['success'] = "Veritabanı başarı bir şekilde geri yüklendi!";
				$this->cache->delete('*');
			}
		}

		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));
	}

	public function export() {

		if (!isset($this->request->post['backup'])) {
			$this->session->data['error'] = "Dışarı aktarmak için en az bir tablo seçmelisiniz!";

			$this->response->redirect($this->url->link('sistem/yedekleme', 'token=' . $this->session->data['token'], true));
		} elseif (!$this->user->hasPermission('modify', 'sistem/yedekleme')) {
			$this->session->data['error'] = "Yedekleme &amp; Geri Yüklemeleri düzenleme iznine sahip değilsiniz!";

			$this->response->redirect($this->url->link('sistem/yedekleme', 'token=' . $this->session->data['token'], true));
		} else {
			$this->response->addheader('Pragma: public');
			$this->response->addheader('Expires: 0');
			$this->response->addheader('Content-Description: File Transfer');
			$this->response->addheader('Content-Type: application/octet-stream');
			$this->response->addheader('Content-Disposition: attachment; filename="' . DB_DATABASE . '_' . date('Y-m-d_H-i-s', time()) . '_backup.sql"');
			$this->response->addheader('Content-Transfer-Encoding: binary');

			$this->load->model('tool/backup');

			$this->response->setOutput($this->model_tool_backup->backup($this->request->post['backup']));		
		}
	}	
}
