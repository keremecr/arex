<?php
class ControllerSistem404 extends Controller {
	public function index() {
		
		$this->document->setTitle("Aradığınız Sayfa Bulunamadı");

		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');

		$this->response->setOutput($this->load->view('sistem/404', $data));
	}
}