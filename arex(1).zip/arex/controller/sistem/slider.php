<?php
class ControllerSistemSlider extends Controller {
	public function index() {
		$data['page_title'] = $this->document->setTitle("Sliderlar");
		$this->sliderlist();
	}
	// slider ekleme
	public function ekle() {
		$this->document->setTitle("Yeni Slider Ekle");
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$data['islem'] = "add";
		$this->load->model('tool/category_list_select');
		$data['lang_array'] = $this->model_tool_category_list_select->lang_array();	
		$data['icerik_array'] = $this->model_tool_category_list_select->icerik_array();	

		if (!$this->user->hasPermission('modify', 'sistem/slider')) {
			$this->response->setOutput($this->load->view('sistem/403', $data));
		}else{
			if (isset($this->request->post['adi'])) {
				$resim = $this->db->escape(trim($this->request->post['resim']));
				$lang_icerik = '';
				foreach ($this->request->post['aciklama'] as $key => $value) {
					$lang_icerik .= '"'.$key.'":"'.trim(base64_encode($value)).'",';
				}
				$lang_icerik = '{'.$lang_icerik.'}';
				$lang_icerik = str_replace(",}", "}", $lang_icerik);	
				$lang_adi = '';
				foreach ($this->request->post['adi'] as $key => $value) {
					$lang_adi .= '"'.$key.'":"'.trim($value).'",';
				}
				$lang_adi = '{'.$lang_adi.'}';				
				$lang_adi = str_replace(",}", "}", $lang_adi);					
				$this->db->query("INSERT INTO slider set adi='".$lang_adi."', aciklama='".$lang_icerik."', resim='".$resim."'");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Slider ekleme işlemi başarılı.";
				}else{
					$this->session->data['error_warning'] = " Slider ekleme işlemi başarısız.";
				}
				$this->response->redirect($this->url->link('sistem/slider', 'token=' . $this->session->data['token'], true));
			}
			$this->response->setOutput($this->load->view('sistem/slider_form', $data));
		}
	}
	// slider düzenleme
	public function duzenle() {
		$this->document->setTitle("Slider Düzenle");
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$data['islem'] = "edit";
		if (!$this->user->hasPermission('modify', 'sistem/slider')) {
			$this->response->setOutput($this->load->view('sistem/403', $data));
		}else{
			if (isset($this->request->get['id'])) {
				$urunum = $this->db->query("SELECT * FROM slider where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				$data['kat'] = $urunum->row;	
				$alangs = json_decode(json_suz($urunum->row['adi']), true);
				$ilangs = json_decode(json_suz($urunum->row['aciklama']), true);						
			}
			$this->load->model('tool/category_list_select');
			$data['lang_array'] = $this->model_tool_category_list_select->lang_array($alangs);	
			$data['icerik_array'] = $this->model_tool_category_list_select->icerik_array($ilangs);			
			if (isset($this->request->post['id'])) {
				$id = $this->db->escape(trim($this->request->post['id']));
				$resim = $this->db->escape(trim($this->request->post['resim']));
				$lang_icerik = '';
				foreach ($this->request->post['aciklama'] as $key => $value) {
					$lang_icerik .= '"'.$key.'":"'.trim(base64_encode($value)).'",';
				}
				$lang_icerik = '{'.$lang_icerik.'}';
				$lang_icerik = str_replace(",}", "}", $lang_icerik);	
				$lang_adi = '';
				foreach ($this->request->post['adi'] as $key => $value) {
					$lang_adi .= '"'.$key.'":"'.trim($value).'",';
				}
				$lang_adi = '{'.$lang_adi.'}';				
				$lang_adi = str_replace(",}", "}", $lang_adi);				
				$this->db->query("UPDATE slider set adi='".$lang_adi."', aciklama='".$lang_icerik."', resim='".$resim."' where id='".$id."' limit 1");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Slider güncelleme işlemi başarılı.";
				}else{
					$this->session->data['error_warning'] = " Slider güncelleme işlemi başarısız.";
				}
				$this->response->redirect($this->url->link('sistem/slider', 'token=' . $this->session->data['token'], true));
			}
			$this->response->setOutput($this->load->view('sistem/slider_form', $data));
		}
	}	
	// slider silme
	public function sil() {
		if (!$this->user->hasPermission('modify', 'sistem/slider')) {
			$this->session->data['error_warning'] = " Bu işlemi yapma yetkiniz bulunmuyor. Lütfen sistem yöneticinize başvurun.";
		}else{
			if (isset($this->request->get['id'])) {
				$varmi = $this->db->query("SELECT * FROM slider where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				if ($varmi->num_rows > 0) {
					$this->db->query("DELETE FROM slider where id='".$this->db->escape($this->request->get['id'])."' limit 1");
					$this->session->data['success'] = " Slider başarıyla silindi.";
				}else{
					$this->session->data['error_warning'] = " Slider bulunamadı.";
				}
			}else{
				$i=0;
				if (isset($this->request->post['selected'])) {
					foreach ($this->request->post['selected'] as $uid) {
						$this->db->query("DELETE FROM slider where id='".$uid."' limit 1");
						$i=1;
					}
				}	
				if ($i==0) {
					$this->session->data['error_warning'] = " Hiç slider seçmediniz. Lütfen slider seçip tekrar deneyin.";
				}else{
					$this->session->data['success'] = " Seçili slider başarıyla silindi.";
				}					
			}
		}
		$this->response->redirect($this->request->server['HTTP_REFERER']);
	}
	// slider listeleme
	protected function sliderlist() {
		$data['token'] = $this->session->data['token'];
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}	
		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->request->get['sayfada']) and !empty($this->request->get['sayfada'])) {
			$data['sayfada'] = $this->request->get['sayfada'];
		} else {
			$data['sayfada'] = '50';
		}	
		//
		$sayfada = $data['sayfada']; // sayfada gösterilecek sayfa miktarını belirtiyoruz.
		 
		$toplam_kayit = $this->db->query("SELECT COUNT(id) FROM slider");
		$toplam_urun = $toplam_kayit->rows[0]['COUNT(id)'];
		if (isset($this->request->get['sayfa'])) {
			$page = $this->request->get['sayfa'];
		}else{
			$page = 1;
		}
		$toplam_sayfa = ceil($toplam_urun / $sayfada);
		$sayfa = isset($page) ? (int) $page : 1;
		if($sayfa < 1) $sayfa = 1; 
		if($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa; 
		$limit = ($sayfa - 1) * $sayfada;
		if ($toplam_urun <1) {
			$limit = 0;
		}		
		//
		$data['slider'] = array();
		$slider = $this->db->query("SELECT * FROM slider order by id asc  LIMIT ".$limit.", ".$sayfada."");	
		$this->load->model('tool/image');
		foreach ($slider->rows as $me) {
			if (is_file(DIR_IMAGE . $me['resim'])) {
				$image = $this->model_tool_image->resize($me['resim'], 400, 100);
			} else {
				$image = $this->model_tool_image->resize('product.png', 400, 100);
			}	
			$adi = json_decode(json_suz($me['adi']), true);
			$aciklama = json_decode(json_suz($me['aciklama']), true);		
			$kats = array(
				'id' => $me['id'], 
				'adi' => $adi[$this->session->data['lang']], 
				'aciklama' => base64_decode($aciklama[$this->session->data['lang']]), 
				'resim' => $image, 
				'duzenle' => $this->url->link('sistem/slider/duzenle&id='.$me['id'], 'token=' . $this->session->data['token'], true),
				'sil' => $this->url->link('sistem/slider/sil&id='.$me['id'], 'token=' . $this->session->data['token'], true)
			);
			$data['slider'][] =  $kats;			
		}
		// sayfalama
		$pagination = new Pagination();
		$pagination->total = $toplam_kayit->rows[0]['COUNT(id)'];
		$pagination->page = $sayfa;
		$pagination->limit = $sayfada;
		$pagination->url = $this->url->link('sistem/slider', 'token=' . $this->session->data['token'].'&sayfa={page}', true);
		$data['pagination'] = $pagination->render();


		$data['ekle'] = $this->url->link('sistem/slider/ekle', 'token=' . $this->session->data['token'], true);
		$data['toplusil'] = $this->url->link('sistem/slider/sil', 'token=' . $this->session->data['token'], true);
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$this->response->setOutput($this->load->view('sistem/slider', $data));
	}	
}