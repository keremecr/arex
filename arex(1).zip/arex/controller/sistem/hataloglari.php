<?php
class ControllerSistemHataloglari extends Controller {
	private $error = array();

	public function index() {		
		$this->document->setTitle("Hata Kayıtları");

		if (isset($this->session->data['error'])) {
			$data['error_warning'] = $this->session->data['error'];

			unset($this->session->data['error']);
		} elseif (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		$data['download'] = $this->url->link('sistem/hataloglari/indir', 'token=' . $this->session->data['token'], true);
		$data['clear'] = $this->url->link('sistem/hataloglari/temizle', 'token=' . $this->session->data['token'], true);

		$data['log'] = '';

		$file = DIR_LOGS . $this->config->get('config_error_filename');

		if (file_exists($file)) {
			$size = filesize($file);

			if ($size >= 5242880) {
				$suffix = array(
					'B',
					'KB',
					'MB',
					'GB',
					'TB',
					'PB',
					'EB',
					'ZB',
					'YB'
				);

				$i = 0;

				while (($size / 1024) > 1) {
					$size = $size / 1024;
					$i++;
				}

				$data['error_warning'] = sprintf("Uyarı: Hata kayıt %s dosyanız %s!", basename($file), round(substr($size, 0, strpos($size, '.') + 4), 2) . $suffix[$i]);
			} else {
				$data['log'] = file_get_contents($file, FILE_USE_INCLUDE_PATH, null);
			}
		}

		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');

		$this->response->setOutput($this->load->view('sistem/hataloglari', $data));
	}

	public function indir() {
		$file = DIR_LOGS . $this->config->get('config_error_filename');
		if (file_exists($file) && filesize($file) > 0) {
			$this->response->addheader('Pragma: public');
			$this->response->addheader('Expires: 0');
			$this->response->addheader('Content-Description: File Transfer');
			$this->response->addheader('Content-Type: application/octet-stream');
			$this->response->addheader('Content-Disposition: attachment; filename="' . $this->config->get('config_name') . '_' . date('Y-m-d_H-i-s', time()) . '_error.log"');
			$this->response->addheader('Content-Transfer-Encoding: binary');
			$this->response->setOutput(file_get_contents($file, FILE_USE_INCLUDE_PATH, null));
		} else {
			$this->session->data['error'] = sprintf("Uyarı: Hata kayıt %s dosyanız %s!", basename($file), '0B');
			$this->response->redirect($this->url->link('sistem/hataloglari', 'token=' . $this->session->data['token'], true));
		}
	}
	
	public function temizle() {
		if (!$this->user->hasPermission('modify', 'sistem/hataloglari')) {
			$this->session->data['error'] = "Hata Kayıtlarını düzenleme iznine sahip değilsiniz!";
		} else {
			$file = DIR_LOGS . $this->config->get('config_error_filename');
			$handle = fopen($file, 'w+');
			fclose($handle);
			$this->session->data['success'] = "Hata kayıtları başarılı bir şekilde temizlendi!";
		}
		$this->response->redirect($this->url->link('sistem/hataloglari', 'token=' . $this->session->data['token'], true));
	}
}