<?php
class ControllerSistemCikis extends Controller {
	public function index() {
		$this->user->logout();
		unset($this->session->data['token']);
		$this->response->redirect($this->url->link('sistem/giris', '', true));
	}
}