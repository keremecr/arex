<?php
class ControllerSistemKategoriler extends Controller {
	public function index() {
		$data['page_title'] = $this->document->setTitle("Kategoriler");
		$this->kategorilist();
	}
	// ürün ekleme
	public function ekle() {
		$data['islem'] = "add";
		$this->document->setTitle("Yeni Kategori Ekle");
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');

		if (!$this->user->hasPermission('modify', 'sistem/kategoriler')) {
			$this->response->setOutput($this->load->view('sistem/403', $data));
		}else{
			$this->load->model('tool/category_list_select');
			$data['lang_array'] = $this->model_tool_category_list_select->lang_array();			
			$data['kats'] = $this->model_tool_category_list_select->kategori_listele();
			if (isset($this->request->post['anakat'])) {
				$data['sira'] = 0;
				$kategoriler = $this->db->query("SELECT * FROM kategoriler order by sira desc limit 1");
				if ($kategoriler->num_rows > 0) {
					$data['sira'] = $kategoriler->row['sira']+1;
				}				
				$ust = $this->db->escape(trim($this->request->post['ust']));
				$alt = $this->db->escape(trim($this->request->post['alt']));
				$ana = $this->db->escape(trim($this->request->post['ana']));
				$anakat = $this->db->escape(trim($this->request->post['anakat']));
				$yonlen = $this->db->escape(trim($this->request->post['yonlen']));
				$lang_icerik = '';
				foreach ($this->request->post['lang'] as $key => $value) {
					$lang_icerik .= '"'.$key.'":"'.trim($value).'",';
				}
				$lang_icerik = '{'.$lang_icerik.'}';
				$lang_icerik = str_replace(",}", "}", $lang_icerik);

				$this->db->query("INSERT INTO kategoriler set langs='".$lang_icerik."', parent='".$anakat."', ust='".$ust."', alt='".$alt."', ana='".$ana."', yonlen='".$yonlen."', sira='".$data['sira']."'");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Kategori ekleme işlemi başarılı.";
				}else{
					$this->session->data['error_warning'] = " Kategori ekleme işlemi başarısız.";
				}
				$this->response->redirect($this->url->link('sistem/kategoriler', 'token=' . $this->session->data['token'], true));
				
			}
			$this->response->setOutput($this->load->view('sistem/kategoriler_form', $data));
		}
	}
	// ürün düzenleme
	public function duzenle() {
		$this->document->setTitle("Kategori Düzenle");
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$data['islem'] = "edit";
		if (!$this->user->hasPermission('modify', 'sistem/kategoriler')) {
			$this->response->setOutput($this->load->view('sistem/403', $data));
		}else{
			if (isset($this->request->get['id'])) {
				$urunum = $this->db->query("SELECT * FROM kategoriler where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				$data['kat'] = $urunum->row;
				$langs = json_decode(json_suz($urunum->row['langs']), true);
				//
				$this->load->model('tool/category_list_select');
				$data['kats'] = $this->model_tool_category_list_select->kategori_listele();	
				$data['lang_array'] = $this->model_tool_category_list_select->lang_array($langs);		
				if ($urunum->row['parent']!=0) {
					$anakategori = $this->db->query("SELECT * FROM kategoriler where id='".$urunum->row['parent']."' limit 1");
					$langs = json_decode(json_suz($anakategori->row['langs']), true);
					$data['anakategori'] = $langs[$this->session->data['lang']];	
					$data['anakategori_id'] = $anakategori->row['id'];				
				}else{
					$data['anakategori'] = "Ana Kategori Yok";	
					$data['anakategori_id'] = 0;	
				}				
			}
			if (isset($this->request->post['id'])) {
				$id = $this->db->escape(trim($this->request->post['id']));
				$ust = $this->db->escape(trim($this->request->post['ust']));
				$alt = $this->db->escape(trim($this->request->post['alt']));
				$ana = $this->db->escape(trim($this->request->post['ana']));
				$anakat = $this->db->escape(trim($this->request->post['anakat']));
				$yonlen = $this->db->escape(trim($this->request->post['yonlen']));
				$lang_icerik = '';
				foreach ($this->request->post['lang'] as $key => $value) {
					$lang_icerik .= '"'.$key.'":"'.trim($value).'",';
				}
				$lang_icerik = '{'.$lang_icerik.'}';
				$lang_icerik = str_replace(",}", "}", $lang_icerik);				
				$this->db->query("UPDATE kategoriler set langs='".$lang_icerik."', parent='".$anakat."', ust='".$ust."', alt='".$alt."', ana='".$ana."', yonlen='".$yonlen."' where id='".$id."' limit 1");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Kategori güncelleme işlemi başarılı.";
				}else{
					$this->session->data['error_warning'] = " Kategori güncelleme işlemi başarısız.";
				}
				$this->response->redirect($this->url->link('sistem/kategoriler', 'token=' . $this->session->data['token'], true));
			}
			$this->response->setOutput($this->load->view('sistem/kategoriler_form', $data));
		}
	}	
	// ürün silme
	public function sil() {
		if (!$this->user->hasPermission('modify', 'sistem/kategoriler')) {
			$this->session->data['error_warning'] = " Bu işlemi yapma yetkiniz bulunmuyor. Lütfen sistem yöneticinize başvurun.";
		}else{
			if (isset($this->request->get['id'])) {
				$varmi = $this->db->query("SELECT * FROM kategoriler where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				if ($varmi->num_rows > 0) {
					$this->db->query("DELETE FROM kategoriler where id='".$this->db->escape($this->request->get['id'])."' limit 1");
					$this->session->data['success'] = " Kategori başarıyla silindi.";
				}else{
					$this->session->data['error_warning'] = " Kategori bulunamadı.";
				}
			}else{
				$i=0;
				if (isset($this->request->post['selected'])) {
					foreach ($this->request->post['selected'] as $uid) {
						$this->db->query("DELETE FROM kategoriler where id='".$uid."' limit 1");
						$i=1;
					}
				}	
				if ($i==0) {
					$this->session->data['error_warning'] = " Hiç kategori seçmediniz. Lütfen kategori seçip tekrar deneyin.";
				}else{
					$this->session->data['success'] = " Seçili kategoriler başarıyla silindi.";
				}					
			}
		}
		$this->response->redirect($this->request->server['HTTP_REFERER']);
	}
	// ürün listeleme
	protected function kategorilist() {
		$data['token'] = $this->session->data['token'];
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}	
		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->request->get['sayfada']) and !empty($this->request->get['sayfada'])) {
			$data['sayfada'] = $this->request->get['sayfada'];
		} else {
			$data['sayfada'] = '50';
		}	
		// lang array
		$this->load->model('tool/category_list_select');
		$data['lang_array'] = $this->model_tool_category_list_select->lang_array();	
		//
		$sayfada = $data['sayfada']; // sayfada gösterilecek ürün miktarını belirtiyoruz.
		 
		$toplam_kayit = $this->db->query("SELECT COUNT(id) FROM kategoriler");
		$toplam_urun = $toplam_kayit->rows[0]['COUNT(id)'];
		if (isset($this->request->get['sayfa'])) {
			$page = $this->request->get['sayfa'];
		}else{
			$page = 1;
		}
		$toplam_sayfa = ceil($toplam_urun / $sayfada);
		$sayfa = isset($page) ? (int) $page : 1;
		if($sayfa < 1) $sayfa = 1; 
		if($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa; 
		$limit = ($sayfa - 1) * $sayfada;
		if ($toplam_urun <1) {
			$limit = 0;
		}		
		//
		$data['kategoriler'] = array();
		$kategoriler = $this->db->query("SELECT * FROM kategoriler order by sira asc  LIMIT ".$limit.", ".$sayfada."");	
		foreach ($kategoriler->rows as $me) {	
		$langs = json_decode(json_suz($me['langs']), true);
		
			$kats = array(
				'adi' => $langs,
				'id' => $me['id'], 
				'parent' => $me['parent'], 
				'ust' => $me['ust'], 
				'alt' => $me['alt'], 
				'ana' => $me['ana'],
				'sira' => $me['sira'], 
				'duzenle' => $this->url->link('sistem/kategoriler/duzenle&id='.$me['id'], 'token=' . $this->session->data['token'], true),
				'sil' => $this->url->link('sistem/kategoriler/sil&id='.$me['id'], 'token=' . $this->session->data['token'], true)
			);
			$data['kategoriler'][] =  $kats;			
		}
		// sayfalama
		$pagination = new Pagination();
		$pagination->total = $toplam_kayit->rows[0]['COUNT(id)'];
		$pagination->page = $sayfa;
		$pagination->limit = $sayfada;
		$pagination->url = $this->url->link('sistem/kategoriler', 'token=' . $this->session->data['token'].'&sayfa={page}', true);
		$data['pagination'] = $pagination->render();


		$data['ekle'] = $this->url->link('sistem/kategoriler/ekle', 'token=' . $this->session->data['token'], true);
		$data['toplusil'] = $this->url->link('sistem/kategoriler/sil', 'token=' . $this->session->data['token'], true);
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$this->response->setOutput($this->load->view('sistem/kategoriler', $data));
	}		
}