<?php
class ControllerSistemSayfalar extends Controller {
	public function index() {
		$data['page_title'] = $this->document->setTitle("Sayfa Yönetimi");
		$this->sayfalist();
	}
	// sayfa ekleme
	public function ekle() {
		$this->document->setTitle("Yeni Sayfa Ekle");
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$data['islem'] = "add";
		$this->load->model('tool/category_list_select');
		$data['lang_array'] = $this->model_tool_category_list_select->lang_array();	
		$data['icerik_array'] = $this->model_tool_category_list_select->icerik_array();	
		$data['kats'] = $this->model_tool_category_list_select->kategori_listele();	
		if (!$this->user->hasPermission('modify', 'sistem/sayfalar')) {
			$this->response->setOutput($this->load->view('sistem/403', $data));
		}else{
			$data['sira'] = "0";
			$sayfalar = $this->db->query("SELECT * FROM sayfalar order by sira desc limit 1");
			if ($sayfalar->num_rows > 0) {
				$data['sira'] = $sayfalar->row['sira']+1;
			}
			if (isset($this->request->post['adi'])) {
				$resim = $this->db->escape(trim($this->request->post['resim']));
				$bresim = $this->db->escape(trim($this->request->post['bresim']));
				$ust = $this->db->escape(trim($this->request->post['ust']));
				$alt = $this->db->escape(trim($this->request->post['alt']));
				$kid = $this->db->escape(trim($this->request->post['kid']));
				$tur = $this->db->escape(trim($this->request->post['tur']));
				$yonlen = $this->db->escape(trim($this->request->post['yonlen']));
				$lang_icerik = '';
				foreach ($this->request->post['editor'] as $key => $value) {
					$lang_icerik .= '"'.$key.'":"'.trim(base64_encode($value)).'",';
				}
				$lang_icerik = '{'.$lang_icerik.'}';
				$lang_icerik = str_replace(",}", "}", $lang_icerik);	
				$lang_adi = '';
				foreach ($this->request->post['adi'] as $key => $value) {
					$lang_adi .= '"'.$key.'":"'.$this->db->escape(trim($value)).'",';
				}
				$lang_adi = '{'.$lang_adi.'}';				
				$lang_adi = str_replace(",}", "}", $lang_adi);				
				$this->db->query("INSERT INTO sayfalar set adi='".$lang_adi."', kid='".$kid."', tur='".$tur."', yonlen='".$yonlen."', aciklama='".$lang_icerik."', resim='".$resim."', bresim='".$bresim."', ust='".$ust."', alt='".$alt."', sira='".$data['sira']."', tarih=NOW()");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Sayfa ekleme işlemi başarılı.";
				}else{
					$this->session->data['error_warning'] = " Sayfa ekleme işlemi başarısız.";
				}
				$this->response->redirect($this->url->link('sistem/sayfalar', 'token=' . $this->session->data['token'], true));
			}
			$this->response->setOutput($this->load->view('sistem/sayfalar_form', $data));
		}
	}	
	// sayfa düzenleme
	public function duzenle() {
		$this->document->setTitle("Sayfa Düzenle");
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$data['islem'] = "edit";
		if (!$this->user->hasPermission('modify', 'sistem/sayfalar')) {
			$this->response->setOutput($this->load->view('sistem/403', $data));
		}else{
			if (isset($this->request->get['id'])) {		
				if (isset($this->session->data['success'])) {
					$data['success'] = $this->session->data['success'];
					unset($this->session->data['success']);
				} else {
					$data['success'] = '';
				}	
				if (isset($this->session->data['error_warning'])) {
					$data['error_warning'] = $this->session->data['error_warning'];
					unset($this->session->data['error_warning']);
				} else {
					$data['error_warning'] = '';
				}				
				$urunum = $this->db->query("SELECT * FROM sayfalar where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				$data['kat'] = $urunum->row;
				$alangs = json_decode(json_suz($urunum->row['adi']), true);
				$ilangs = json_decode(json_suz($urunum->row['aciklama']), true);
				// kategoriler	
				//echo "<textarea>".json_suz($urunum->row['aciklama'])."</textarea>";
				$kategoriler = $this->db->query("SELECT * FROM kategoriler order by sira asc");
				$data['kategoriler'] = $kategoriler->rows;
				if ($urunum->row['kid']!=0) {
					$kategorim = $this->db->query("SELECT * FROM kategoriler where id='".$urunum->row['kid']."' limit 1");
					$langs = json_decode(json_suz($kategorim->row['langs']), true);
					$data['kategorim'] = $langs[$this->session->data['lang']];	
					$data['kategorim_id'] = $kategorim->row['id'];						
				}
				$this->load->model('tool/category_list_select');
				$data['kats'] = $this->model_tool_category_list_select->kategori_listele();
				$data['lang_array'] = $this->model_tool_category_list_select->lang_array($alangs);	
				$data['icerik_array'] = $this->model_tool_category_list_select->icerik_array($ilangs);

				$galerim = $this->db->query("SELECT * FROM galeri where sid='".$this->db->escape($this->request->get['id'])."'");
				foreach ($galerim->rows as $ap) {
					$langs = json_decode(json_suz($ap['adi']), true);
					if (is_file(DIR_IMAGE . $ap['resim'])) {
						$proje_resim = $this->model_tool_image->resize($ap['resim'], 285, 213);
					} else {
						$proje_resim = $this->model_tool_image->resize("product.png", 285, 213);
					}					
					$kats = array(
						'id' => $ap['id'], 
						'adi' => $langs[$this->session->data['lang']], 
						'resim' => $proje_resim, 
						'sil' => $this->url->link('sistem/sayfalar/galeri_resim_sil&id='.$ap['id'], 'token=' . $this->session->data['token'], true)
					);	
					$data['galerim'][] =  $kats;	
				}
				$vgalerim = $this->db->query("SELECT * FROM vgaleri where sid='".$this->db->escape($this->request->get['id'])."'");
				foreach ($vgalerim->rows as $ap) {
					$langs = json_decode(json_suz($ap['adi']), true);
					if (is_file(DIR_IMAGE . $ap['resim'])) {
						$proje_resim = $this->model_tool_image->resize($ap['resim'], 285, 213);
					} else {
						$proje_resim = $this->model_tool_image->resize("product.png", 285, 213);
					}					
					$kats = array(
						'id' => $ap['id'], 
						'adi' => $langs[$this->session->data['lang']], 
						'resim' => $proje_resim, 
						'video' => $ap['video'], 
						'sil' => $this->url->link('sistem/sayfalar/galeri_video_sil&id='.$ap['id'], 'token=' . $this->session->data['token'], true)
					);	
					$data['vgalerim'][] =  $kats;	
				}				
			}
			if (isset($this->request->post['id'])) {
				$id = $this->db->escape(trim($this->request->post['id']));
				$resim = $this->db->escape(trim($this->request->post['resim']));
				$bresim = $this->db->escape(trim($this->request->post['bresim']));
				$ust = $this->db->escape(trim($this->request->post['ust']));
				$alt = $this->db->escape(trim($this->request->post['alt']));
				$kid = $this->db->escape(trim($this->request->post['kid']));
				$tur = $this->db->escape(trim($this->request->post['tur']));
				$yonlen = $this->db->escape(trim($this->request->post['yonlen']));
				$lang_icerik = '';
				foreach ($this->request->post['editor'] as $key => $value) {
					$lang_icerik .= '"'.$key.'":"'.trim(base64_encode($value)).'",';
				}
				$lang_icerik = '{'.$lang_icerik.'}';
				$lang_icerik = str_replace(",}", "}", $lang_icerik);	
				$lang_adi = '';
				foreach ($this->request->post['adi'] as $key => $value) {
					$lang_adi .= '"'.$key.'":"'.trim($value).'",';
				}
				$lang_adi = '{'.$lang_adi.'}';				
				$lang_adi = str_replace(",}", "}", $lang_adi);					
				$this->db->query("UPDATE sayfalar set adi='".$lang_adi."', kid='".$kid."', tur='".$tur."', yonlen='".$yonlen."', aciklama='".$lang_icerik."', resim='".$resim."', bresim='".$bresim."', ust='".$ust."', alt='".$alt."' where id='".$id."' limit 1");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Sayfa güncelleme işlemi başarılı.";
				}else{
					$this->session->data['error_warning'] = " Sayfa güncelleme işlemi başarısız.";
				}
				$this->response->redirect($this->url->link('sistem/sayfalar', 'token=' . $this->session->data['token'], true));
			}
			if (isset($this->request->post['proje_adi'])) {
				$proje_resim = $this->db->escape(trim($this->request->post['proje_resim']));
				$proje_adi = '';
				foreach ($this->request->post['proje_adi'] as $key => $value) {
					$proje_adi .= '"'.$key.'":"'.trim($value).'",';
				}
				$proje_adi = '{'.$proje_adi.'}';				
				$proje_adi = str_replace(",}", "}", $proje_adi);
				$this->db->query("INSERT INTO galeri set adi='".$proje_adi."', resim='".$proje_resim."', sid='".$this->db->escape($this->request->get['id'])."'");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Proje Resmi Yüklendi.";
				}else{
					$this->session->data['error_warning'] = "İşlem Başarısız.";
				}		
				//print_r("INSERT INTO galeri set adi='".$proje_adi."', resim='".$proje_resim."', sid='".$this->db->escape($this->request->get['id'])."'");		
				$this->response->redirect($this->url->link('sistem/sayfalar/duzenle&id='.$this->db->escape($this->request->get['id']), 'token=' . $this->session->data['token'], true));
			}	
			if (isset($this->request->post['proje_video'])) {
				$proje_video = $this->db->escape(trim($this->request->post['proje_video']));
				$proje_resim2 = $this->db->escape(trim($this->request->post['proje_resim2']));
				$this->db->query("INSERT INTO vgaleri set resim='".$proje_resim2."', video='".$proje_video."', sid='".$this->db->escape($this->request->get['id'])."'");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Video Yüklendi.";
				}else{
					$this->session->data['error_warning'] = "İşlem Başarısız.";
				}			
				$this->response->redirect($this->url->link('sistem/sayfalar/duzenle&id='.$this->db->escape($this->request->get['id']), 'token=' . $this->session->data['token'], true));
			}					
			$this->response->setOutput($this->load->view('sistem/sayfalar_form', $data));
		}
	}	
	// sayfa düzenleme
	public function anasayfa() {
		$this->document->setTitle("Ana Sayfa Yönetimi");
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$this->load->model('tool/category_list_select');
		///
		if (!$this->user->hasPermission('modify', 'sistem/sayfalar')) {
			$this->response->setOutput($this->load->view('sistem/403', $data));
		}else{
			$data['lang_array'] = $this->model_tool_category_list_select->lang_array();	
			if (isset($this->session->data['success'])) {
				$data['success'] = $this->session->data['success'];
				unset($this->session->data['success']);
			} else {
				$data['success'] = '';
			}	
			if (isset($this->session->data['error_warning'])) {
				$data['error_warning'] = $this->session->data['error_warning'];
				unset($this->session->data['error_warning']);
			} else {
				$data['error_warning'] = '';
			}
			$duyurum = $this->db->query("SELECT * FROM anasayfa limit 1");
			$data['duyuru'] = $duyurum->row['duyuru'];
			// 
			$anasayfa_proje = $this->db->query("SELECT * FROM anasayfa_proje");
			foreach ($anasayfa_proje->rows as $ap) {
				$langs = json_decode(json_suz($ap['adi']), true);
				if (is_file(DIR_IMAGE . $ap['resim'])) {
					$proje_resim = $this->model_tool_image->resize($ap['resim'], 285, 213);
				} else {
					$proje_resim = $this->model_tool_image->resize("product.png", 285, 213);
				}					
				$kats = array(
					'id' => $ap['id'], 
					'adi' => $langs[$this->session->data['lang']], 
					'resim' => $proje_resim, 
					'sil' => $this->url->link('sistem/sayfalar/proje_resim_sil&id='.$ap['id'], 'token=' . $this->session->data['token'], true)
				);	
				$data['anasayfa_proje'][] =  $kats;	
			}
			// duyuru güncelleme			
			if (isset($this->request->post['editor'])) {
				$this->db->query("UPDATE anasayfa set duyuru='".$this->db->escape(trim($this->request->post['editor']))."'");
				$this->response->redirect($this->url->link('sistem/sayfalar/anasayfa', 'token=' . $this->session->data['token'], true));
			}
			$proje_resim="";
			// proje resi ekleniyor			
			if (isset($this->request->post['proje_adi'])) {
				$proje_resim = $this->db->escape(trim($this->request->post['proje_resim']));
				$proje_adi = '';
				foreach ($this->request->post['proje_adi'] as $key => $value) {
					$proje_adi .= '"'.$key.'":"'.trim($value).'",';
				}
				$proje_adi = '{'.$proje_adi.'}';				
				$proje_adi = str_replace(",}", "}", $proje_adi);
				$this->db->query("INSERT INTO anasayfa_proje set adi='".$proje_adi."', resim='".$proje_resim."'");
				if ($this->db->countAffected() > 0) {
					$this->session->data['success'] = " Proje Resmi Yüklendi.";
				}else{
					$this->session->data['error_warning'] = "İşlem Başarısız.";
				}				
				$this->response->redirect($this->url->link('sistem/sayfalar/anasayfa', 'token=' . $this->session->data['token'], true));
			}
			$this->response->setOutput($this->load->view('sistem/anasayfa_form', $data));
		}
	}
	// anasayfa resim silme
	public function proje_resim_sil() {
		if (!$this->user->hasPermission('modify', 'sistem/sayfalar')) {
			$this->session->data['error_warning'] = " Bu işlemi yapma yetkiniz bulunmuyor. Lütfen sistem yöneticinize başvurun.";
		}else{
			if (isset($this->request->get['id'])) {
				$varmi = $this->db->query("SELECT * FROM anasayfa_proje where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				if ($varmi->num_rows > 0) {
					$this->db->query("DELETE FROM anasayfa_proje where id='".$this->db->escape($this->request->get['id'])."' limit 1");
					$this->session->data['success'] = " Resim başarıyla silindi.";
				}else{
					$this->session->data['error_warning'] = " Resim bulunamadı.";
				}
			}
		}
		$this->response->redirect($this->request->server['HTTP_REFERER']);
	}		
	// galeri resim silme
	public function galeri_resim_sil() {
		if (!$this->user->hasPermission('modify', 'sistem/sayfalar')) {
			$this->session->data['error_warning'] = " Bu işlemi yapma yetkiniz bulunmuyor. Lütfen sistem yöneticinize başvurun.";
		}else{
			if (isset($this->request->get['id'])) {
				$varmi = $this->db->query("SELECT * FROM galeri where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				if ($varmi->num_rows > 0) {
					$this->db->query("DELETE FROM galeri where id='".$this->db->escape($this->request->get['id'])."' limit 1");
					$this->session->data['success'] = " Resim başarıyla silindi.";
				}else{
					$this->session->data['error_warning'] = " Resim bulunamadı.";
				}
			}
		}
		$this->response->redirect($this->request->server['HTTP_REFERER']);
	}
	// galeri resim silme
	public function galeri_video_sil() {
		if (!$this->user->hasPermission('modify', 'sistem/sayfalar')) {
			$this->session->data['error_warning'] = " Bu işlemi yapma yetkiniz bulunmuyor. Lütfen sistem yöneticinize başvurun.";
		}else{
			if (isset($this->request->get['id'])) {
				$varmi = $this->db->query("SELECT * FROM vgaleri where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				if ($varmi->num_rows > 0) {
					$this->db->query("DELETE FROM vgaleri where id='".$this->db->escape($this->request->get['id'])."' limit 1");
					$this->session->data['success'] = " Video başarıyla silindi.";
				}else{
					$this->session->data['error_warning'] = " Video bulunamadı.";
				}
			}
		}
		$this->response->redirect($this->request->server['HTTP_REFERER']);
	}	
	// sayfa silme
	public function sil() {
		if (!$this->user->hasPermission('modify', 'sistem/sayfalar')) {
			$this->session->data['error_warning'] = " Bu işlemi yapma yetkiniz bulunmuyor. Lütfen sistem yöneticinize başvurun.";
		}else{
			if (isset($this->request->get['id'])) {
				$varmi = $this->db->query("SELECT * FROM sayfalar where id='".$this->db->escape($this->request->get['id'])."' limit 1");
				if ($varmi->num_rows > 0) {
					$this->db->query("DELETE FROM sayfalar where id='".$this->db->escape($this->request->get['id'])."' limit 1");
					$this->session->data['success'] = " Sayfa başarıyla silindi.";
				}else{
					$this->session->data['error_warning'] = " Sayfa bulunamadı.";
				}
			}else{
				$i=0;
				if (isset($this->request->post['selected'])) {
					foreach ($this->request->post['selected'] as $uid) {
						$this->db->query("DELETE FROM sayfalar where id='".$uid."' limit 1");
						$i=1;
					}
				}	
				if ($i==0) {
					$this->session->data['error_warning'] = " Hiç sayfa seçmediniz. Lütfen sayfa seçip tekrar deneyin.";
				}else{
					$this->session->data['success'] = " Seçili sayfalar başarıyla silindi.";
				}					
			}
		}
		$this->response->redirect($this->request->server['HTTP_REFERER']);
	}
	// sayfa listeleme
	protected function sayfalist() {
		$data['token'] = $this->session->data['token'];
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}	
		if (isset($this->session->data['error_warning'])) {
			$data['error_warning'] = $this->session->data['error_warning'];
			unset($this->session->data['error_warning']);
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->request->get['sayfada']) and !empty($this->request->get['sayfada'])) {
			$data['sayfada'] = $this->request->get['sayfada'];
		} else {
			$data['sayfada'] = '50';
		}	
		//
		$sayfada = $data['sayfada']; // sayfada gösterilecek sayfa miktarını belirtiyoruz.
		 
		$toplam_kayit = $this->db->query("SELECT COUNT(id) FROM sayfalar");
		$toplam_urun = $toplam_kayit->rows[0]['COUNT(id)'];
		if (isset($this->request->get['sayfa'])) {
			$page = $this->request->get['sayfa'];
		}else{
			$page = 1;
		}
		$toplam_sayfa = ceil($toplam_urun / $sayfada);
		$sayfa = isset($page) ? (int) $page : 1;
		if($sayfa < 1) $sayfa = 1; 
		if($sayfa > $toplam_sayfa) $sayfa = $toplam_sayfa; 
		$limit = ($sayfa - 1) * $sayfada;
		if ($toplam_urun <1) {
			$limit = 0;
		}		
		//
		$data['sayfalar'] = array();
		$sayfalar = $this->db->query("SELECT * FROM sayfalar order by sira asc  LIMIT ".$limit.", ".$sayfada."");	
		$this->load->model('tool/image');
		foreach ($sayfalar->rows as $me) {
			if (is_file(DIR_IMAGE . $me['resim'])) {
				$image = $this->model_tool_image->resize($me['resim'], 40, 40);
			} else {
				$image = $this->model_tool_image->resize("product.png", 40, 40);
			}	
			$langs = json_decode(json_suz($me['adi']), true);
			$katadi = "";
			$katbul = $this->db->query("select * from kategoriler where id='".$me['kid']."' limit 1");	
			if ($katbul->num_rows > 0) {
				$clangs = json_decode(json_suz($katbul->row['langs']), true);
				$katadi = $clangs[$this->session->data['lang']];
			}	

			$kats = array(
				'id' => $me['id'], 
				'adi' => $langs[$this->session->data['lang']], 
				'katadi' => $katadi, 
				'resim' => $image, 
				'ust' => $me['ust'], 
				'alt' => $me['alt'], 
				'tur' => $me['tur'], 
				'sira' => $me['sira'], 
				'duzenle' => $this->url->link('sistem/sayfalar/duzenle&id='.$me['id'], 'token=' . $this->session->data['token'], true),
				'sil' => $this->url->link('sistem/sayfalar/sil&id='.$me['id'], 'token=' . $this->session->data['token'], true)
			);
			$data['sayfalar'][] =  $kats;			
		}
		$data['user_lang'] = $this->session->data['lang'];
		// sayfalama
		$pagination = new Pagination();
		$pagination->total = $toplam_kayit->rows[0]['COUNT(id)'];
		$pagination->page = $sayfa;
		$pagination->limit = $sayfada;
		$pagination->url = $this->url->link('sistem/sayfalar', 'token=' . $this->session->data['token'].'&sayfa={page}', true);
		$data['pagination'] = $pagination->render();


		$data['ekle'] = $this->url->link('sistem/sayfalar/ekle', 'token=' . $this->session->data['token'], true);
		$data['toplusil'] = $this->url->link('sistem/sayfalar/sil', 'token=' . $this->session->data['token'], true);
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$this->response->setOutput($this->load->view('sistem/sayfalar', $data));
	}	
}