<?php
class ControllerSistemAyarlar extends Controller {
	public function index() {
		$this->document->setTitle("Site Ayarları");
		if (isset($this->request->post['url'])) {
			$url = $this->db->escape(trim($this->request->post['url']));
			$logo = $this->db->escape(trim($this->request->post['logo']));
			$adi = $this->db->escape(trim($this->request->post['adi']));
			$adres = $this->db->escape(trim($this->request->post['adres']));
			$tel = $this->db->escape(trim($this->request->post['tel']));
			$fax = $this->db->escape(trim($this->request->post['fax']));
			$email = $this->db->escape(trim($this->request->post['email']));
			$title = $this->db->escape(trim($this->request->post['title']));
			$description = $this->db->escape(trim($this->request->post['description']));
			$keywords = $this->db->escape(trim($this->request->post['keywords']));
			$metatag = $this->db->escape(trim($this->request->post['metatag']));
			$analytics = $this->db->escape(trim($this->request->post['analytics']));
			$facebook = $this->db->escape(trim($this->request->post['facebook']));
			$twitter = $this->db->escape(trim($this->request->post['twitter']));
			$google = $this->db->escape(trim($this->request->post['google']));
			$kurumsal_takip = $this->db->escape(trim($this->request->post['kurumsal_takip']));
			$sube_girisi = $this->db->escape(trim($this->request->post['sube_girisi']));
			$calisma = $this->db->escape(trim($this->request->post['calisma']));
			$haftasonu = $this->db->escape(trim($this->request->post['haftasonu']));
			$harita = $this->db->escape(trim($this->request->post['harita']));
			$harita2 = ""; //$this->db->escape(trim($this->request->post['harita2']));
			$favicon = $this->db->escape(trim($this->request->post['favicon']));
			$this->db->query("UPDATE ayarlar set url='".$url."', logo='".$logo."', adi='".$adi."', adres='".$adres."', tel='".$tel."', fax='".$fax."', email='".$email."', title='".$title."', description='".$description."', keywords='".$keywords."', metatag='".$metatag."', analytics='".$analytics."', facebook='".$facebook."', twitter='".$twitter."', google='".$google."', kurumsal_takip='".$kurumsal_takip."', sube_girisi='".$sube_girisi."', calisma='".$calisma."', haftasonu='".$haftasonu."', harita='".$harita."', harita2='".$harita2."', favicon='".$favicon."' where id='1' limit 1");
			$this->session->data['success'] = "Site ayarları başarıyla kaydedildi. ";
			$this->response->redirect($this->url->link('sistem/ayarlar', 'token=' . $this->session->data['token'], true));
		}
		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];
			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}	
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");	
		$data['set'] = $ayarlar->row;
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');
		$this->response->setOutput($this->load->view('sistem/ayarlar', $data));
	}
}