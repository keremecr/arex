<?php
class ControllerSistemAnasayfa extends Controller {
	public function index() {
		if (!isset($this->session->data['token'])) {
			$this->response->redirect($this->url->link('sistem/giris', '', true));
		}		
		$this->document->setTitle("Ana Sayfa");
		$data['token'] = $this->session->data['token'];
		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');


		$sayfalar = $this->db->query("SELECT * FROM sayfalar");
		$data['toplam_sayfalar'] = $sayfalar->num_rows;	
		//
		$kategoriler = $this->db->query("SELECT * FROM kategoriler");
		$data['toplam_kategoriler'] = $kategoriler->num_rows;		
	
		$sliders = $this->db->query("SELECT * FROM slider");
		$data['toplam_slider'] = $sliders->num_rows;	
		//

		$this->response->setOutput($this->load->view('sistem/anasayfa', $data));
	}
}