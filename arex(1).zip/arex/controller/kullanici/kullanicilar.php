<?php
class ControllerKullaniciKullanicilar extends Controller {
	private $error = array();

	public function index() {
		$this->document->setTitle("Kullanıcılar");
		$this->load->model('kullanici/kullanicilar');
		
		$this->getList();
	}

	public function add() {
		$this->document->setTitle("Kullanıcı Ekle");
		$this->load->model('kullanici/kullanicilar');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_kullanici_kullanicilar->addUser($this->request->post);

			$this->session->data['success'] = "Kullanıcı başarıyla eklendi!";

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . $url, true));
		}
		$this->getForm();
	}

	public function edit() {
		$this->document->setTitle("Kullanıcı Düzenle");
		$this->load->model('kullanici/kullanicilar');
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validateForm()) {
			$this->model_kullanici_kullanicilar->editUser($this->request->get['user_id'], $this->request->post);
			$this->session->data['success'] = "Kullanıcı bilgileri başarıyla güncellendi!";

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . $url, true));
		}
		$this->getForm();
	}

	public function delete() {
		$this->document->setTitle("Kullanıcı Sil");
		$this->load->model('kullanici/kullanicilar');
		if (isset($this->request->post['selected']) && $this->validateDelete()) {
			foreach ($this->request->post['selected'] as $user_id) {
				$this->model_kullanici_kullanicilar->deleteUser($user_id);
			}
			$this->session->data['success'] = "Kullanıcı başarıyla silindi!";

			$url = '';

			if (isset($this->request->get['sort'])) {
				$url .= '&sort=' . $this->request->get['sort'];
			}

			if (isset($this->request->get['order'])) {
				$url .= '&order=' . $this->request->get['order'];
			}

			if (isset($this->request->get['page'])) {
				$url .= '&page=' . $this->request->get['page'];
			}

			$this->response->redirect($this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . $url, true));
		}
		$this->getList();
	}

	protected function getList() {
		if (isset($this->request->get['sort'])) {
			$sort = $this->request->get['sort'];
		} else {
			$sort = 'username';
		}

		if (isset($this->request->get['order'])) {
			$order = $this->request->get['order'];
		} else {
			$order = 'ASC';
		}

		if (isset($this->request->get['page'])) {
			$page = $this->request->get['page'];
		} else {
			$page = 1;
		}

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['add'] = $this->url->link('kullanici/kullanicilar/add', 'token=' . $this->session->data['token'] . $url, true);
		$data['delete'] = $this->url->link('kullanici/kullanicilar/delete', 'token=' . $this->session->data['token'] . $url, true);

		$data['users'] = array();

		$filter_data = array(
			'sort'  => $sort,
			'order' => $order,
			'start' => ($page - 1) * $this->config->get('config_limit_admin'),
			'limit' => $this->config->get('config_limit_admin')
		);

		$user_total = $this->model_kullanici_kullanicilar->getTotalUsers();

		$results = $this->model_kullanici_kullanicilar->getUsers($filter_data);

		foreach ($results as $result) {
			$grubu = $this->db->query("SELECT * FROM user_group where user_group_id='".$result['user_group_id']."' limit 1");
			$data['users'][] = array(
				'grup'    => $grubu->row['name'],
				'user_id'    => $result['user_id'],
				'username'   => $result['username'],
				'firstname'   => $result['firstname'],
				'lastname'   => $result['lastname'],
				'email'   => $result['email'],
				'status'     => ($result['status'] ? "Açık" : "Kapalı"),
				'date_added' => $result['date_added'],
				'edit'       => $this->url->link('kullanici/kullanicilar/edit', 'token=' . $this->session->data['token'] . '&user_id=' . $result['user_id'] . $url, true)
			);
		}

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->session->data['success'])) {
			$data['success'] = $this->session->data['success'];

			unset($this->session->data['success']);
		} else {
			$data['success'] = '';
		}

		if (isset($this->request->post['selected'])) {
			$data['selected'] = (array)$this->request->post['selected'];
		} else {
			$data['selected'] = array();
		}

		$url = '';

		if ($order == 'ASC') {
			$url .= '&order=DESC';
		} else {
			$url .= '&order=ASC';
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		$data['sort_username'] = $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . '&sort=username' . $url, true);
		$data['sort_firstname'] = $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . '&sort=firstname' . $url, true);
		$data['sort_email'] = $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . '&sort=email' . $url, true);
		$data['sort_status'] = $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . '&sort=status' . $url, true);
		$data['sort_date_added'] = $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . '&sort=date_added' . $url, true);

		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		$pagination = new Pagination();
		$pagination->total = $user_total;
		$pagination->page = $page;
		$pagination->limit = $this->config->get('config_limit_admin');
		$pagination->url = $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . $url . '&page={page}', true);

		$data['pagination'] = $pagination->render();

		$data['results'] = sprintf("Gösterilen: %d ile %d arası, toplam: %d (%d Sayfa) ", ($user_total) ? (($page - 1) * $this->config->get('config_limit_admin')) + 1 : 0, ((($page - 1) * $this->config->get('config_limit_admin')) > ($user_total - $this->config->get('config_limit_admin'))) ? $user_total : ((($page - 1) * $this->config->get('config_limit_admin')) + $this->config->get('config_limit_admin')), $user_total, ceil($user_total / $this->config->get('config_limit_admin')));

		$data['sort'] = $sort;
		$data['order'] = $order;

		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');

		$this->response->setOutput($this->load->view('kullanici/kullanici_listesi', $data));
	}

	protected function getForm() {
		$data['text_form'] = !isset($this->request->get['user_id']) ? "Kullanıcı Ekle" : "Kullanıcı Düzenle";

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['username'])) {
			$data['error_username'] = $this->error['username'];
		} else {
			$data['error_username'] = '';
		}

		if (isset($this->error['password'])) {
			$data['error_password'] = $this->error['password'];
		} else {
			$data['error_password'] = '';
		}

		if (isset($this->error['confirm'])) {
			$data['error_confirm'] = $this->error['confirm'];
		} else {
			$data['error_confirm'] = '';
		}

		if (isset($this->error['firstname'])) {
			$data['error_firstname'] = $this->error['firstname'];
		} else {
			$data['error_firstname'] = '';
		}

		if (isset($this->error['lastname'])) {
			$data['error_lastname'] = $this->error['lastname'];
		} else {
			$data['error_lastname'] = '';
		}
		
		if (isset($this->error['email'])) {
			//$data['error_email'] = $this->error['email'];
		} else {
			$data['error_email'] = '';
		}
		
		$url = '';

		if (isset($this->request->get['sort'])) {
			$url .= '&sort=' . $this->request->get['sort'];
		}

		if (isset($this->request->get['order'])) {
			$url .= '&order=' . $this->request->get['order'];
		}

		if (isset($this->request->get['page'])) {
			$url .= '&page=' . $this->request->get['page'];
		}

		if (!isset($this->request->get['user_id'])) {
			$data['action'] = $this->url->link('kullanici/kullanicilar/add', 'token=' . $this->session->data['token'] . $url, true);
		} else {
			$data['action'] = $this->url->link('kullanici/kullanicilar/edit', 'token=' . $this->session->data['token'] . '&user_id=' . $this->request->get['user_id'] . $url, true);
		}

		$data['cancel'] = $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'] . $url, true);

		if (isset($this->request->get['user_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$user_info = $this->model_kullanici_kullanicilar->getUser($this->request->get['user_id']);
		}

		if (isset($this->request->post['username'])) {
			$data['username'] = $this->request->post['username'];
		} elseif (!empty($user_info)) {
			$data['username'] = $user_info['username'];
		} else {
			$data['username'] = '';
		}

		if (isset($this->request->post['user_group_id'])) {
			$data['user_group_id'] = $this->request->post['user_group_id'];
		} elseif (!empty($user_info)) {
			$data['user_group_id'] = $user_info['user_group_id'];
		} else {
			$data['user_group_id'] = '';
		}

		$this->load->model('kullanici/kullanici_gruplari');

		$data['user_groups'] = $this->model_kullanici_kullanici_gruplari->getUserGroups();

		if (isset($this->request->post['password'])) {
			$data['password'] = $this->request->post['password'];
		} else {
			$data['password'] = '';
		}

		if (isset($this->request->post['confirm'])) {
			$data['confirm'] = $this->request->post['confirm'];
		} else {
			$data['confirm'] = '';
		}

		if (isset($this->request->post['firstname'])) {
			$data['firstname'] = $this->request->post['firstname'];
		} elseif (!empty($user_info)) {
			$data['firstname'] = $user_info['firstname'];
		} else {
			$data['firstname'] = '';
		}

		if (isset($this->request->post['lastname'])) {
			$data['lastname'] = $this->request->post['lastname'];
		} elseif (!empty($user_info)) {
			$data['lastname'] = $user_info['lastname'];
		} else {
			$data['lastname'] = '';
		}

		if (isset($this->request->post['email'])) {
			$data['email'] = $this->request->post['email'];
		} elseif (!empty($user_info)) {
			$data['email'] = $user_info['email'];
		} else {
			$data['email'] = '';
		}

		if (isset($this->request->post['image'])) {
			$data['image'] = $this->request->post['image'];
		} elseif (!empty($user_info)) {
			$data['image'] = $user_info['image'];
		} else {
			$data['image'] = '';
		}

		$this->load->model('tool/image');

		if (isset($this->request->post['image']) && is_file(DIR_IMAGE . $this->request->post['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($this->request->post['image'], 100, 100);
		} elseif (!empty($user_info) && $user_info['image'] && is_file(DIR_IMAGE . $user_info['image'])) {
			$data['thumb'] = $this->model_tool_image->resize($user_info['image'], 100, 100);
		} else {
			$data['thumb'] = $this->model_tool_image->resize('no_image.png', 100, 100);
		}
		
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 100, 100);

		if (isset($this->request->post['status'])) {
			$data['status'] = $this->request->post['status'];
		} elseif (!empty($user_info)) {
			$data['status'] = $user_info['status'];
		} else {
			$data['status'] = 0;
		}

		$data['header'] = $this->load->controller('inc/header');
		$data['column_left'] = $this->load->controller('inc/left');
		$data['footer'] = $this->load->controller('inc/footer');

		$this->response->setOutput($this->load->view('kullanici/kullanici_formu', $data));
	}

	protected function validateForm() {
		if (!$this->user->hasPermission('modify', 'kullanici/kullanicilar')) {
			$this->error['warning'] = "Uyarı: Kullanıcıları düzenleme iznine sahip değilsiniz!";
		}

		if ((utf8_strlen($this->request->post['username']) < 3) || (utf8_strlen($this->request->post['username']) > 20)) {
			$this->error['username'] = "Kullanıcı Adı 3 ile 20 karakter arasında olmalı!";
		}

		$user_info = $this->model_kullanici_kullanicilar->getUserByUsername($this->request->post['username']);

		if (!isset($this->request->get['user_id'])) {
			if ($user_info) {
				$this->error['warning'] = "Uyarı: Kullanıcı adı zaten kullanılıyor!";
			}
		} else {
			if ($user_info && ($this->request->get['user_id'] != $user_info['user_id'])) {
				$this->error['warning'] = "Uyarı: Kullanıcı adı zaten kullanılıyor!";
			}
		}

		if ((utf8_strlen(trim($this->request->post['firstname'])) < 1) || (utf8_strlen(trim($this->request->post['firstname'])) > 32)) {
			$this->error['firstname'] = "Ad 1 ile 32 karakter arasında olmalı! ";
		}

		if ((utf8_strlen(trim($this->request->post['lastname'])) < 1) || (utf8_strlen(trim($this->request->post['lastname'])) > 32)) {
			$this->error['lastname'] = "Soyadı 1 ile 32 karakter arasında olmalı!";
		}
		
		if ((utf8_strlen($this->request->post['email']) > 96) || !filter_var($this->request->post['email'], FILTER_VALIDATE_EMAIL)) {
			//$this->error['email'] = $this->language->get('error_email');
		}
		if ($this->request->post['email']=="") {
			
		}else{
			$user_info = $this->model_kullanici_kullanicilar->getUserByEmail($this->request->post['email']);
			if (!isset($this->request->get['user_id'])) {
				if ($user_info) {
					$this->error['warning'] = "Uyarı: E-Posta adresiyle kayıtlı bir kullanıcı var!";
				}
			} else {
				if ($user_info && ($this->request->get['user_id'] != $user_info['user_id'])) {
					$this->error['warning'] = "Uyarı: E-Posta adresiyle kayıtlı bir kullanıcı var!";
				}
			}			
		}
		
		if ($this->request->post['password'] || (!isset($this->request->get['user_id']))) {
			if ((utf8_strlen(html_entity_decode($this->request->post['password'], ENT_QUOTES, 'UTF-8')) < 4) || (utf8_strlen(html_entity_decode($this->request->post['password'], ENT_QUOTES, 'UTF-8')) > 40)) {
				$this->error['password'] = "Parola 4 ile 20 karakter arasında olmalı!";
			}

			if ($this->request->post['password'] != $this->request->post['confirm']) {
				$this->error['confirm'] = "Şifre birbiriyle uyuşmuyor!";
			}
		}

		return !$this->error;
	}

	protected function validateDelete() {
		if (!$this->user->hasPermission('modify', 'kullanici/kullanicilar')) {
			$this->error['warning'] = "Uyarı: Kullanıcıları düzenleme iznine sahip değilsiniz! ";
		}

		foreach ($this->request->post['selected'] as $user_id) {
			if ($this->user->getId() == $user_id) {
				$this->error['warning'] = "Uyarı: Kendi hesabınızı silemezsiniz!";
			}
		}

		return !$this->error;
	}
}