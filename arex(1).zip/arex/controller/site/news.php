<?php
class ControllerSiteNews extends Controller {
	public function index() {
		include 'system/lang/'.$this->session->data['lang'].'.php';
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];
		$this->load->model('tool/image');	
		//	
		$tk_resim = "";
		$aciklama = "";
		if (isset($this->request->get['page_id'])) {
			$id = $this->db->escape($this->request->get['page_id']);
			$page = $this->db->query("SELECT * FROM sayfalar where id='".$id."' and tur='Haber' limit 1");
			foreach ($page->rows as $val) {
				if (isset($val['resim']) && is_file(DIR_IMAGE . $val['resim'])) {
					$tk_resim = $this->model_tool_image->resize($val['resim'], 500, 434);
				} else {
					$tk_resim = "";
				}				
				$adi = json_decode(json_suz($val['adi']), true);
				$aciklama = json_decode(json_suz($val['aciklama']), true);
				$data['tarih'] = $val['tarih'];
			}
			$data['page_name'] = $adi[$this->session->data['lang']];
			$data['page_description'] = html_entity_decode(base64_decode($aciklama[$this->session->data['lang']]));
			$data['page_image'] = $tk_resim;
			$data['social_url'] = $data['ayar']['url']."news/".$id;
			$this->document->setTitle($data['page_name']." - ".$data['ayar']['adi']);

		$haberler = $this->db->query("SELECT * FROM sayfalar where tur='Haber' order by id desc limit 6");
		foreach ($haberler->rows as $hab) {
			if (isset($hab['resim']) && is_file(DIR_IMAGE . $hab['resim'])) {
				$hab_resim = $this->model_tool_image->resize($hab['resim'], 363, 315);
			} else {
				$hab_resim = $this->model_tool_image->resize("news_no.jpg", 363, 315);
			}			
			$adi = json_decode(json_suz($hab['adi']), true);
			$aciklama = json_decode(json_suz($hab['aciklama']), true);
			$sl = array(
				'adi' => $adi[$this->session->data['lang']], 
				'aciklama' => substr(strip_tags(html_entity_decode(base64_decode($aciklama[$this->session->data['lang']]))), 0, 120),
				'tarih' => $hab['tarih'],
				'resim' => $hab_resim,
				'id' => $hab['id'],
			);
			$data['haberler'][] = $sl;
		}
			
			$data['header'] = $this->load->controller('site/header');
			$data['footer'] = $this->load->controller('site/footer');
			$this->response->setOutput($this->load->view('site/news', $data));
		}else{

		}
	}
	public function all() {
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];		
		include 'system/lang/'.$this->session->data['lang'].'.php';
		$this->load->model('tool/image');
		$data['page_name'] = $data['menu_news'];
		$haberler = $this->db->query("SELECT * FROM sayfalar where tur='Haber' order by id desc limit 6");
		foreach ($haberler->rows as $hab) {
			if (isset($hab['resim']) && is_file(DIR_IMAGE . $hab['resim'])) {
				$hab_resim = $this->model_tool_image->resize($hab['resim'], 363, 315);
			} else {
				$hab_resim = $this->model_tool_image->resize("news_no.jpg", 363, 315);
			}			
			$adi = json_decode(json_suz($hab['adi']), true);
			$aciklama = json_decode(json_suz($hab['aciklama']), true);
			$sl = array(
				'adi' => $adi[$this->session->data['lang']], 
				'aciklama' => substr(strip_tags(html_entity_decode(base64_decode($aciklama[$this->session->data['lang']]))), 0, 120),
				'tarih' => $hab['tarih'],
				'resim' => $hab_resim,
				'id' => $hab['id'],
			);
			$data['haberler'][] = $sl;
		}		
		$this->document->setTitle($data['menu_news']." - ".$data['ayar']['adi']);
		$data['header'] = $this->load->controller('site/header');
		$data['footer'] = $this->load->controller('site/footer');
		$this->response->setOutput($this->load->view('site/news_all', $data));
	}
}