<?php
class ControllerSiteFooter extends Controller {
	public function index() {
		// ayarlar
		include 'system/lang/'.$this->session->data['lang'].'.php';
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];
		$data['ayar_adres'] = str_replace("\r\n", "<br>", $ayarlar->row['adres']);

		$data['yil'] = date("Y");
		$data['categories'] = $this->parents(0,0);
		$data['base'] = HTTPS_SERVER;

		// sayfalar
		$sayfalar = $this->db->query("select * from sayfalar where alt='Aktif' and kid=0 and tur='Normal' order by sira asc limit 10");
		$slist = '';
		foreach ($sayfalar->rows as $val) {
			$langs = json_decode(json_suz($val['adi']), true);
			$slist .= '<li><a href="page/'.$val['id'].'"><span>'.$langs[$this->session->data['lang']].'</span></a></li>';					
		}
		$data['pages'] = $slist;

		// sayfalar
		$icerikler = $this->db->query("select * from sayfalar where alt='Aktif' and (kid!=0 and tur='Normal' or kid=0 and tur='Haber') order by id asc limit 10");
		$ilist = '';
		foreach ($icerikler->rows as $val) {
			$langs = json_decode(json_suz($val['adi']), true);
			$ilist .= '<li><a href="page/'.$val['id'].'"><span>'.$langs[$this->session->data['lang']].'</span></a></li>';						
		}
		$data['ilist'] = $ilist;

		return $this->load->view('site/inc/footer', $data);
	}

	protected function parents($kid=0, $ul=0){
		$kats = "";
		$parents = $this->db->query("SELECT * FROM kategoriler where alt='Aktif' and parent='".$kid."' order by sira asc limit 10");
		if ($parents->num_rows > 0) {
			if($ul==0){ $kats .= "<ul class='menu'>"; }
			foreach ($parents->rows as $val) {
				$kadi = json_decode(json_suz($val['langs']), true);
				$kats .= "<li class='menu-item' style='border-top: 1px solid rgba(255, 255, 255, 0.09);'><a href='category/".$val['id']."'>".$kadi[$this->session->data['lang']]."</a>";
				$kats .= $this->parents($val['id']);
				$kats .= "</li>";	
			}
			if($ul==0){ $kats .= "</ul>"; }	
		}
		return $kats;
	}	
}