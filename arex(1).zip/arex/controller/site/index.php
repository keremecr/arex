<?php
class ControllerSiteIndex extends Controller {
	public function index() {
		include 'system/lang/'.$this->session->data['lang'].'.php';
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->row;
		$data['ayar']['description'] = str_replace("\r\n", "<br>", $ayarlar->row['description']);
		$this->document->setTitle($data['ayar']['title']);
		// anasayfa
		$this->load->model('tool/image');




		// kategoriler
		$icerikler = array();
		$katlar = array();
		$kategoriler=$this->db->query("SELECT *, k.id AS kategoriid, s.id AS sayfaid FROM kategoriler k INNER JOIN sayfalar s ON k.id=s.kid where k.ana='Aktif' order by k.sira asc");
		foreach ($kategoriler->rows as $ka => $kat) {
			$kadi = json_decode(json_suz($kat['langs']), true);
			if (isset($kat['resim']) && is_file(DIR_IMAGE . $kat['resim'])) {
				$say_resim = $this->model_tool_image->resize($kat['resim'], 350, 220);
			}else{
				$say_resim = $this->model_tool_image->resize("news_no.png", 350, 220);
			}	

							
				$aciklama = json_decode(json_suz($kat['aciklama']), true);
				$adi = json_decode(json_suz($kat['adi']), true);
				$icerikler[] = array(
					'id' => $kat['sayfaid'], 
					'adi' => $adi[$this->session->data['lang']], 
					'aciklama' => substr(strip_tags(html_entity_decode(base64_decode($aciklama[$this->session->data['lang']]))), 0, 120),
					'resim' => $say_resim,
				);
		}
			$katlar[] = array(
				'id' => $kat['kategoriid'],
				'adi' => $kadi[$this->session->data['lang']],
				'sayfalar' => $icerikler,
			);
		$data['kategoriler'] = $katlar;


		$data['unixtime'] = time();

		$duyurum = $this->db->query("SELECT * FROM anasayfa limit 1");
		$data['duyuru'] = html_entity_decode($duyurum->row['duyuru']);

		$haberler = $this->db->query("SELECT * FROM sayfalar where tur='Haber' order by id desc limit 6");
		foreach ($haberler->rows as $hab) {
			if (isset($hab['resim']) && is_file(DIR_IMAGE . $hab['resim'])) {
				$hab_resim = $this->model_tool_image->resize($hab['resim'], 363, 315);
			} else {
				$hab_resim = $this->model_tool_image->resize("news_no.jpg", 363, 315);
			}			
			$adi = json_decode(json_suz($hab['adi']), true);
			$aciklama = json_decode(json_suz($hab['aciklama']), true);
			$sl = array(
				'adi' => $adi[$this->session->data['lang']], 
				'aciklama' => substr(strip_tags(html_entity_decode(base64_decode($aciklama[$this->session->data['lang']]))), 0, 120),
				'tarih' => $hab['tarih'],
				'resim' => $hab_resim,
				'id' => $hab['id'],
			);
			$data['haberler'][] = $sl;
		}			
		$sliders = $this->db->query("SELECT * FROM slider");
		foreach ($sliders->rows as $val) {
			$adi = json_decode(json_suz($val['adi']), true);
			$aciklama = json_decode(json_suz($val['aciklama']), true);
			$sl[] = array(
				'adi' => $adi[$this->session->data['lang']], 
				'aciklama' => base64_decode($aciklama[$this->session->data['lang']]),
				'resim' => $this->model_tool_image->resize($val['resim'], 1920, 1080),
				'id' => $val['id']
			);
			
		}$data['slider'] = $sl;
		// anasayfa projeler
		$anasayfa_proje = $this->db->query("SELECT * FROM galeri");
		foreach ($anasayfa_proje->rows as $ap) {
			$langs = json_decode(json_suz($ap['adi']), true);
			if (is_file(DIR_IMAGE . $ap['resim'])) {
				$proje_resim = $this->model_tool_image->resize($ap['resim'], 285, 213);
			} else {
				$proje_resim = $this->model_tool_image->resize("product.png", 285, 213);
			}					
			$kats = array(
				'id' => $ap['id'], 
				'adi' => $langs[$this->session->data['lang']], 
				'resim' => $proje_resim,
				'large' => $ap['resim'],
			);	
			$data['anasayfa_proje'][] =  $kats;	
		}		
		$data['top'] = $this->load->controller('site/top');
		$data['header'] = $this->load->controller('site/header');
		$data['footer'] = $this->load->controller('site/footer');
		$this->response->setOutput($this->load->view('site/index', $data));
		// 
	}
	public function test() {
		print_r($this->request->get);
	}
}