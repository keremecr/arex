<?php
class ControllerSitePage extends Controller {
	public function index() {
		include 'system/lang/' . $this->session->data['lang'] . '.php';
		// ayarlar
		$ayarlar      = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];
		$this->load->model('tool/image');
		$data['base'] = HTTPS_SERVER;
		//
		$tk_resim = "";
		$aciklama = "";
		if (isset($this->request->get['page_id'])) {
			$id   = $this->db->escape($this->request->get['page_id']);
			$page = $this->db->query("SELECT * FROM sayfalar where id='" . $id . "' limit 1");
			foreach ($page->rows as $val) {
				if (isset($val['resim']) && is_file(DIR_IMAGE . $val['resim'])) {
					$tk_resim = $this->model_tool_image->resize($val['resim'], 350, 220);
				} else {
					$tk_resim = "";
				}
				if (isset($val['bresim']) && is_file(DIR_IMAGE . $val['bresim'])) {
					$page_bimage = $this->model_tool_image->resize($val['bresim'], 1920, 300);
				} else {
					$page_bimage = "";
				}
				$adi      = json_decode(json_suz($val['adi']), true);
				$aciklama = json_decode(json_suz($val['aciklama']), true);
				if ($val['kid'] != 0) {
					$this->load->model('tool/category_list_select');
					$data['breadcrumbs'] = $this->model_tool_category_list_select->page_breadcrumbs($val['kid']);
				} else {
					$data['breadcrumbs'] = "";
				}
				if (strlen($val['yonlen']) > 5) {
					$this->response->redirect(HTTP_SERVER.$val['yonlen']);
				}
			}
			$data['pageno'] = $id;
			$data['tur'] = $val['tur'];
		}
		
		// galeri
		$galerim = $this->db->query("SELECT * FROM galeri where sid='".$id."'");
		foreach ($galerim->rows as $ap) {
			$langs = json_decode(json_suz($ap['adi']), true);
			if (is_file(DIR_IMAGE . $ap['resim'])) {
				$proje_resim = $this->model_tool_image->resize($ap['resim'], 285, 213);
				$large = $this->model_tool_image->resize($ap['resim'], 1024, 768);
			} else {
				$proje_resim = $this->model_tool_image->resize("product.png", 285, 213);
				$ap['resim'] = $this->model_tool_image->resize("product.png", 285, 213);
			}					
			$kats = array(
				'id' => $ap['id'], 
				'adi' => $langs[$this->session->data['lang']], 
				'resim' => $proje_resim,
				'large' => $ap['resim'],
			);	
			$data['galerim'][] =  $kats;	
		}		
		// anasayfa projeler
		$anasayfa_proje = $this->db->query("SELECT * FROM anasayfa_proje");
		foreach ($anasayfa_proje->rows as $ap) {
			$langs = json_decode(json_suz($ap['adi']), true);
			if (is_file(DIR_IMAGE . $ap['resim'])) {
				$proje_resim = $this->model_tool_image->resize($ap['resim'], 285, 213);
			} else {
				$proje_resim = $this->model_tool_image->resize("product.png", 285, 213);
				$ap['resim'] = $this->model_tool_image->resize("product.png", 285, 213);
			}					
			$kats = array(
				'id' => $ap['id'], 
				'adi' => $langs[$this->session->data['lang']], 
				'resim' => $proje_resim,
				'large' => $ap['resim'],
			);	
			$data['anasayfa_proje'][] =  $kats;	
		}
				
		$data['top'] = $this->load->controller('site/top');
		$data['page_name']        = $adi[$this->session->data['lang']];
		$data['page_description'] = html_entity_decode(base64_decode($aciklama[$this->session->data['lang']]));
		$data['page_image']       = $tk_resim;
		$data['page_bimage']       = $page_bimage;
		$this->document->setTitle($data['page_name'] . " - " . $data['ayar']['adi']);

		$data['header'] = $this->load->controller('site/header');
		$data['footer'] = $this->load->controller('site/footer');

		$this->load->model('tool/image');

		$this->response->setOutput($this->load->view('site/page', $data));
	}

	public function takip()
	{			include 'system/lang/' . $this->session->data['lang'] . '.php';
		// ayarlar
		$ayarlar      = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];
		$data['top'] = $this->load->controller('site/top');
		$this->document->setTitle("Gönderi Sorgula - " . $data['ayar']['adi']);

		$data['header'] = $this->load->controller('site/header');
		$data['footer'] = $this->load->controller('site/footer');
		
		$req = isset($this->request->server['REQUEST_URI']) ? $this->request->server['REQUEST_URI'] : '';
		$data['barcode'] = explode('html?barcode=', $req)[1];

		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['base'] = HTTPS_SERVER;
		$this->response->setOutput($this->load->view('site/takip', $data));
	}
}