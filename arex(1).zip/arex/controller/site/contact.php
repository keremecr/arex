<?php
class ControllerSiteContact extends Controller {
	public function index() {
		include DIR_SYSTEM.'library/smtp/phpmailer.php';
		include 'system/lang/'.$this->session->data['lang'].'.php';
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->row;	
		$data['ayar_adres'] = str_replace("\r\n", "<br>", $ayarlar->row['adres']);
		//	
		$this->document->setTitle($data['menu_contact']." - ".$data['ayar']['adi']);
		
		$data['header'] = $this->load->controller('site/header');
		$data['footer'] = $this->load->controller('site/footer');
		$data['top'] = $this->load->controller('site/top');
		if (isset($this->request->post['name'])) {
			$email = $this->request->post['email'];
			$adsoyad = $this->request->post['name'];
			$mesaj = $this->request->post['message'];
			$tel = $this->request->post['tel'];
			$mail = new PHPMailer(); 
			$mail->IsSMTP(); 
			$mail->SMTPDebug = 1; 
			$mail->SMTPAuth = true; 
			$mail->SMTPSecure = '0'; // secure transfer enabled REQUIRED for GMail
			$mail->Host = "mail.abdullahsakin.com";
			$mail->Port = 587; // or 587
			$mail->IsHTML(true);
			$mail->SetLanguage("tr", "phpmailer/language");
			$mail->CharSet  ="utf-8";

			$mail->Username = "iletisim@abdullahsakin.com"; // Mail adresi
			$mail->Password = "fx20qz60+*"; // Parola
			$mail->SetFrom($email, $adsoyad); // Mail adresi

			$mail->AddAddress($ayarlar->row['email']); // Gönderilecek kişi
			$mail->AddReplyTo($email, $adsoyad); // Yanıtlanacak kişi

			$mail->Subject = "İletişim Mesajı";
			$mail->Body = "Aşağıdaki bilgiler web siteniz ".$_SERVER['HTTP_HOST']." aracılığı ile gönderilmiştir.<br><br>Adı Soyası : ".$adsoyad."<br />E-Mail : ".$email."<br />Telefon : ".$tel."<br />Mesaj : ".$mesaj;

			if(!$mail->Send()){
			     $data['message_send'] = "error";
			} else {
				$data['message_send'] = "success";
			}	
			$data['name'] = $adsoyad;
			$data['email'] = $email;
			$data['tel'] = $tel;
			$data['message'] = $mesaj;
		}

  
		
		$this->response->setOutput($this->load->view('site/contact', $data));
	}
}