<?php
class ControllerSiteHeader extends Controller {
	public function index() {
		include 'system/lang/'.$this->session->data['lang'].'.php';
		$data['title'] = $this->document->getTitle();
		if (isset($this->request->get['lang'])) {
			if ($this->request->get['lang']=="tr") {
				$this->session->data['lang'] = "tr";
			}elseif ($this->request->get['lang']=="en") {
				$this->session->data['lang'] = "en";
			}else{
				$this->session->data['lang'] = "tr";
			}
			$this->response->redirect($this->request->server['HTTP_REFERER']);
		}
		$data['uri'] = $this->request->server['REQUEST_URI'];
		if (strstr($data['uri'], '/team')) {
			$data['team_active'] = 1;
		}
		if ($data['uri']=="/") {
			$data['home_active'] = 1;
		}	
		if (strstr($data['uri'], '/contact')) {
			$data['contact_active'] = 1;
		}	
		if (strstr($data['uri'], '/news')) {
			$data['news_active'] = 1;
		}	
		if (strstr($data['uri'], '/press')) {
			$data['press_active'] = 1;
		}				
		$this->load->model('tool/category_list_select');
		$data['lang_array'] = $this->model_tool_category_list_select->lang_array();
		$data['user_lang'] = lang_array()[$this->session->data['lang']];
		$data['user_lang_short'] = $this->session->data['lang'];
		
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];
		$data['ayar']['url'] = HTTPS_SERVER;
		$data['base'] = HTTPS_SERVER;
		// kategoriler
		$data['anakats'] = $this->parents(0,1);
		$data['manakats'] = $this->mparents(0,1);

		// sayfalar
		$sayfalar = $this->db->query("select * from sayfalar where ust='Aktif' and kid=0 and tur='Normal' order by sira asc");
		$slist = '';
		foreach ($sayfalar->rows as $val) {
			$langs = json_decode(json_suz($val['adi']), true);
			if (isset($this->request->get['page_id']) and $this->request->get['page_id']==$val['id']) {
				$slist .= '<li class="menu-item active"><a href="page/'.$val['id'].'" class="white menu2"><span>'.$langs[$this->session->data['lang']].'</span></a></li>';
			}else{
				$slist .= '<li class="menu-item"><a href="page/'.$val['id'].'" class="white menu2"><span>'.$langs[$this->session->data['lang']].'</span></a></li>';
			}						
		}
		$data['pages'] = $slist;
		return $this->load->view('site/inc/header', $data);
	}
	protected function sayfas($kid=0){
		$kats = "";
		$sayfalar = $this->db->query("SELECT * FROM sayfalar where kid='".$kid."' and ust='Aktif'");
		if ($sayfalar->num_rows > 0) {
			foreach ($sayfalar->rows as $say) {
				$sadi = json_decode(json_suz($say['adi']), true);
				$kats .= "<li><a href='page/".$say['id']."'>".$sadi[$this->session->data['lang']]."</a></li>";
			}
		}	
		return $kats;
	}
	protected function msayfas($kid=0){
		$kats = "";
		$sayfalar = $this->db->query("SELECT * FROM sayfalar where kid='".$kid."' and ust='Aktif'");
		if ($sayfalar->num_rows > 0) {
			foreach ($sayfalar->rows as $say) {
				$sadi = json_decode(json_suz($say['adi']), true);
				$kats .= "<li class='menu-item menu-item-type-custom menu-item-object-custom'><a href='page/".$say['id']."'>".$sadi[$this->session->data['lang']]."</a></li>";
			}
		}	
		return $kats;
	}
	protected function parents($kid=0, $ul=0){
		$kats = "";
		$parents = $this->db->query("SELECT * FROM kategoriler where ust='Aktif' and parent='".$kid."' order by sira asc");
		if ($parents->num_rows > 0) {
			if($ul==0){ $kats .= "<ul class='ssub-menu'>"; }
			foreach ($parents->rows as $val) {
				$kadi = json_decode(json_suz($val['langs']), true);
				//$kats .= "<li class='dropdown'><a href='category/".$val['id']."'>".$kadi[$this->session->data['lang']]."</a>";
				$kats .= "<li class='menu-item'><a href='javascript:;'>".$kadi[$this->session->data['lang']]."</a>";
				if ($this->sayfas($val['id'])!="") {
					$kats .= "<ul class='sub-menu'>";
					$kats .= $this->sayfas($val['id']);
					$kats .= $this->parents($val['id'], 1);
					$kats .= "</ul>";
				}else{
					$kats .= $this->parents($val['id']);
				}
				$kats .= "</li>";	
			}
			if($ul==0){ $kats .= "</ul>"; }	
		}
		return $kats;
	}
	protected function mparents($kid=0, $ul=0){
		$kats = "";
		$parents = $this->db->query("SELECT * FROM kategoriler where ust='Aktif' and parent='".$kid."' order by sira asc");
		if ($parents->num_rows > 0) {
			if($ul==0){ $kats .= "<ul class='sub-menu'>"; }
			foreach ($parents->rows as $val) {
				$kadi = json_decode(json_suz($val['langs']), true);
				//$kats .= "<li class='dropdown'><a href='category/".$val['id']."'>".$kadi[$this->session->data['lang']]."</a>";
				$kats .= "<li class='menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children'><a href='javascript:;'>".$kadi[$this->session->data['lang']]."</a>";
				if ($this->msayfas($val['id'])!="") {
					$kats .= "<ul class='sub-menu'>";
					$kats .= $this->msayfas($val['id']);
					$kats .= $this->mparents($val['id'], 1);
					$kats .= "</ul>";
				}else{
					$kats .= $this->mparents($val['id']);
				}
				$kats .= "</li>";	
			}
			if($ul==0){ $kats .= "</ul>"; }	
		}
		return $kats;
	}
}