<?php
class ControllerSiteTop extends Controller {
	public function index() {
		include 'system/lang/'.$this->session->data['lang'].'.php';
		$data['title'] = $this->document->getTitle();
		if (isset($this->request->get['lang'])) {
			if ($this->request->get['lang']=="tr") {
				$this->session->data['lang'] = "tr";
			}elseif ($this->request->get['lang']=="en") {
				$this->session->data['lang'] = "en";
			}else{
				$this->session->data['lang'] = "tr";
			}
			$this->response->redirect($this->request->server['HTTP_REFERER']);
		}
		$data['uri'] = $this->request->server['REQUEST_URI'];

		$this->load->model('tool/category_list_select');
		$data['lang_array'] = $this->model_tool_category_list_select->lang_array();
		$data['user_lang'] = lang_array()[$this->session->data['lang']];
		$data['user_lang_short'] = $this->session->data['lang'];
		
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];
		$data['ayar']['url'] = HTTPS_SERVER;

		return $this->load->view('site/inc/top', $data);
	}
}