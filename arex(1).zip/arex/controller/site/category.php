<?php
class ControllerSiteCategory extends Controller {
	public function index() {
		include 'system/lang/'.$this->session->data['lang'].'.php';
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->row;	

					
		if (isset($this->request->get['cat_id'])) {
			$id = $this->db->escape($this->request->get['cat_id']);
			//	
			$current = $this->db->query("SELECT * FROM kategoriler where id='".$id."' limit 1");
			if ($current->num_rows < 1) {
	 			$this->response->redirect(HTTP_SERVER);
	 			exit;			
			}else{
				$adi = json_decode(json_suz($current->row['langs']), true);
				$data['page_name'] = $adi[$this->session->data['lang']];
				if ($current->row['yonlen']!="") {
					$this->response->redirect(HTTP_SERVER.$current->row['yonlen']);
				}
			}	
			$this->load->model('tool/category_list_select');
			$this->load->model('tool/image');
			$data['breadcrumbs'] = $this->model_tool_category_list_select->cat_breadcrumbs($id);	
			$pages = $this->db->query("SELECT * FROM sayfalar where kid='".$id."' order by id asc");
			foreach ($pages->rows as $val) {
				$adi = json_decode(json_suz($val['adi']), true);
				$aciklama = json_decode(json_suz($val['aciklama']), true);
				$resim = $val['resim'];
				if (isset($val['resim']) && is_file(DIR_IMAGE . $val['resim'])) {
					$tk_resim = $this->model_tool_image->resize($val['resim'], 120, 107);
				} else {
					$tk_resim = "";
				}				
				$sayf = array(
					'id' => $val['id'], 
					'adi' => $adi[$this->session->data['lang']], 
					'aciklama' => substr(strip_tags(html_entity_decode(base64_decode($aciklama[$this->session->data['lang']]))),0,600), 
					'resim' => $tk_resim
				);
				$data['pages'][] = $sayf;
			}
		}

		$this->document->setTitle($data['page_name']." - ".$data['ayar']['adi']);
		


		$data['header'] = $this->load->controller('site/header');
		$data['footer'] = $this->load->controller('site/footer');

		$this->load->model('tool/image');
  
		
		$this->response->setOutput($this->load->view('site/category', $data));
	}
}