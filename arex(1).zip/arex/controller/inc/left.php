<?php
class ControllerIncLeft extends Controller {
	public function index() {
		if (isset($this->session->data['token'])) {
			// Menu
			$data['menus'][] = array(
				'id'       => 'menu-dashboard',
				'icon'	   => 'fa-dashboard',
				'name'	   => "Ana Sayfa",
				'href'     => $this->url->link('sistem/anasayfa', 'token=' . $this->session->data['token'], true),
				'children' => array()
			);
			// Sayfa Yönetimi
			$sayfa = array();
			if ($this->user->hasPermission('access', 'sistem/sayfalar')) {	
				$sayfa[] = array(
					'name'	   => "Sayfa Yönetimi",
					'href'     => $this->url->link('sistem/sayfalar', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);	
			}	
			if ($this->user->hasPermission('access', 'sistem/kategoriler')) {	
				$sayfa[] = array(
					'name'	   => "Kategori Yönetimi",
					'href'     => $this->url->link('sistem/kategoriler', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);	
			}	
			if ($this->user->hasPermission('access', 'sistem/sayfalar')) {	
				$sayfa[] = array(
					'name'	   => "Anasayfa Yönetimi",
					'href'     => $this->url->link('sistem/sayfalar/anasayfa', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);	
			}				
			if ($this->user->hasPermission('access', 'sistem/ekibimiz')) {	
				$sayfa[] = array(
					'name'	   => "Avukat Yönetimi",
					'href'     => $this->url->link('sistem/ekibimiz', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);	
			}		
			if ($this->user->hasPermission('access', 'sistem/slider')) {	
				$sayfa[] = array(
					'name'	   => "Slider Yönetimi",
					'href'     => $this->url->link('sistem/slider', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);	
			}							
			if ($sayfa) {
				$data['menus'][] = array(
					'id'       => 'menu-sayfa',
					'icon'	   => 'fa-file-text-o', 
					'name'	   => "Sayfa Yönetimi",
					'href'     => '',
					'children' => $sayfa
				);
			}				
			// Users
			$user = array();
			if ($this->user->hasPermission('access', 'kullanici/kullanicilar')) {
				$user[] = array(
					'name'	   => "Kullanıcılar",
					'href'     => $this->url->link('kullanici/kullanicilar', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);	
			}
			if ($this->user->hasPermission('access', 'kullanici/kullanici_gruplari')) {	
				$user[] = array(
					'name'	   => "Kullanıcı Grupları",
					'href'     => $this->url->link('kullanici/kullanici_gruplari', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);	
			}
			if ($user) {
				$data['menus'][] = array(
					'id'       => 'menu-system',
					'icon'	   => 'fa-users', 
					'name'	   => "Kullanıcı İşlemleri",
					'href'     => '',
					'children' => $user
				);
			}
			// Users
			$system = array();	
			if ($this->user->hasPermission('access', 'sistem/ayarlar')) {
				$system[] = array(
					'name'	   => "Site Ayarları",
					'href'     => $this->url->link('sistem/ayarlar', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);
			}	
			if ($this->user->hasPermission('access', 'sistem/yedekleme')) {
				$system[] = array(
					'name'	   => "Yedekle & Geri Yükle",
					'href'     => $this->url->link('sistem/yedekleme', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);
			}
			if ($this->user->hasPermission('access', 'sistem/hataloglari')) {
				$system[] = array(
					'name'	   => "Hata Kayıtları",
					'href'     => $this->url->link('sistem/hataloglari', 'token=' . $this->session->data['token'], true),
					'children' => array()		
				);
			}				
			if ($system) {
				$data['menus'][] = array(
					'id'       => 'menu-system',
					'icon'	   => 'fa-cog', 
					'name'	   => "Sistem",
					'href'     => '',
					'children' => $system
				);
			}
			
			return $this->load->view('inc/left', $data);
		}
	}
}