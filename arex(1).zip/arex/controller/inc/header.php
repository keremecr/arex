<?php
class ControllerIncHeader extends Controller {
	public function index() {
		$data['title'] = $this->document->getTitle();
		$data['heading_title'] = "Ana Sayfa";
		// ayarlar
		$ayarlar = $this->db->query("SELECT * FROM ayarlar where id='1' limit 1");
		$data['ayar'] = $ayarlar->rows[0];
		//
		if ($this->request->server['HTTPS']) {
			$data['base'] = HTTPS_SERVER;
		} else {
			$data['base'] = HTTP_SERVER;
		}
		if (!isset($this->session->data['token'])) {
			$data['logged'] = '';

			$data['home'] = $this->url->link('sistem/anasayfa', '', true);
		} else {
			$data['logged'] = true;

			$data['home'] = $this->url->link('sistem/anasayfa', 'token=' . $this->session->data['token'], true);
			$data['logout'] = $this->url->link('sistem/cikis', 'token=' . $this->session->data['token'], true);
			$data['profile'] = $this->url->link('kullanici/profil', 'token=' . $this->session->data['token'], true);
		
			$this->load->model('kullanici/kullanicilar');
	
			$this->load->model('tool/image');
	
			$user_info = $this->model_kullanici_kullanicilar->getUser($this->user->getId());
	
			if ($user_info) {
				$data['firstname'] = $user_info['firstname'];
				$data['lastname'] = $user_info['lastname'];
				$data['username']  = $user_info['username'];
				$data['user_group'] = $user_info['user_group'];
	
				if (is_file(DIR_IMAGE . $user_info['image'])) {
					$data['image'] = $this->model_tool_image->resize($user_info['image'], 45, 45);
				} else {
					$data['image'] = $this->model_tool_image->resize('profile.png', 45, 45);
				}
			} else {
				$data['firstname'] = '';
				$data['lastname'] = '';
				$data['user_group'] = '';
				$data['image'] = '';
			}			
			
			// Online Stores
			$data['stores'] = array();

			$data['stores'][] = array(
				'name' => $this->config->get('config_name'),
				'href' => HTTP_SERVER
			);
		}

		return $this->load->view('inc/header', $data);
	}
}