<?php
class ControllerIncFooter extends Controller {
	public function index() {

		if (isset($this->session->data['token'])) {
			$data['footer'] = "";
		} else {
			$data['footer'] = "";
		}
		
		return $this->load->view('inc/footer', $data);
	}
}
