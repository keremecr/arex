<?php
class ControllerStartupStartup extends Controller {
	public function index() {
		$this->registry->set('user', new Cart\User($this->registry));
		// Settings
		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "setting WHERE store_id = '0'");
		foreach ($query->rows as $setting) {
			if (!$setting['serialized']) {
				$this->config->set($setting['key'], $setting['value']);
			} else {
				$this->config->set($setting['key'], json_decode($setting['value'], true));
			}
		}
		if (!isset($this->session->data['lang'])) {
			$this->session->data['lang'] = "tr";
		}		
		//////////////////////////////////////////////////////////////////
		/*
		if (isset($this->session->data['token'])) {
			if (!isset($this->request->get['rota'])) {
				header("location:index.php?rota=sistem/anasayfa&token=".$this->session->data['token']);
				exit;
			}
		}
		if (isset($this->session->data['token'])) {
			if (isset($this->request->get['token'])) {
				if ($this->request->get['token'] != $this->session->data['token']) {
					header("location:index.php?rota=sistem/cikis&token=".$this->session->data['token']);
					exit;					
				}
			}
		}
		if (isset($this->session->data['token'])) {
			if (!isset($this->request->get['token']) && isset($this->request->get['rota'])) {
				header("location:".str_replace("&amp;","&",$this->request->server['REQUEST_URI'])."&token=".$this->session->data['token']);
				exit;
			}
		}
		*/



		/////////////////////////////////////
		function token($length = 32) {
			// Create random token
			$string = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
			
			$max = strlen($string) - 1;
			
			$token = '';
			
			for ($i = 0; $i < $length; $i++) {
				$token .= $string[mt_rand(0, $max)];
			}	
			
			return $token;
		}
		function lang_array() {
			//$lang = array('tr'=>'Türkçe');
			$lang = array('tr'=>'Türkçe','en'=>'English');
			return $lang;
		}	
		function json_suz($str) {
			$json = trim(str_replace(PHP_EOL, " ", $str));
			return $json;
		}			
		////////////////////////////////////////
	}

}