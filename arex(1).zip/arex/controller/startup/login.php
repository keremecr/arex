<?php
class ControllerStartupLogin extends Controller {
	public function index() {
		$rota = isset($this->request->get['rota']) ? $this->request->get['rota'] : '';
		// Login olmadan görüntülenebilecek modüller.
		$ignore = array(
			'sistem/giris',
			'site/index',
			'site/page',
			'site/contact',
			'site/category',
			'site/news',
			'',

		);
		// User
		
		if (!$this->user->isLogged() && !in_array($rota, $ignore)) {
			return new Action('sistem/giris');
		}
	}
}
