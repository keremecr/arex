<?php
class ControllerStartupRouter extends Controller {
	public function index() {
		// Route
		if (isset($this->request->get['rota']) && $this->request->get['rota'] != 'startup/router') {
			$rota = $this->request->get['rota'];
		} else {
			$rota = $this->config->get('action_default');
		}
		
		$data = array();
		
		// Sanitize the call
		$rota = preg_replace('/[^a-zA-Z0-9_\/]/', '', (string)$rota);
		
		// Trigger the pre events
		$result = $this->event->trigger('controller/' . $rota . '/before', array(&$rota, &$data));
		
		if (!is_null($result)) {
			return $result;
		}
		
		$action = new Action($rota);
		
		// Any output needs to be another Action object. 
		$output = $action->execute($this->registry, $data);
		
		// Trigger the post events
		$result = $this->event->trigger('controller/' . $rota . '/after', array(&$rota, &$output));
		
		if (!is_null($result)) {
			return $result;
		}
		
		return $output;
	}
}
