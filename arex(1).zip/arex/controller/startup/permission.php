
<?php
class ControllerStartupPermission extends Controller {
	public function index() {
		if (isset($this->request->get['rota'])) {
			$rota = '';

			$part = explode('/', $this->request->get['rota']);

			if (isset($part[0])) {
				$rota .= $part[0];
			}

			if (isset($part[1])) {
				$rota .= '/' . $part[1];
			}

			// Login olduktan sonra görüntülenebilecek modüller.
			$ignore = array(
			'inc/footer',
			'inc/header',
			'inc/left',
			'sistem/403',
			'sistem/404',
			'sistem/anasayfa',
			'sistem/giris',
			'sistem/cikis',
			'startup/login',
			'startup/permission',
			'startup/router',
			'startup/startup',
			'site/index',
			'site/page',
			'site/contact',		
			'site/category',
			'site/news',
			'site/press',
			'',		
			);

			if (!in_array($rota, $ignore) && !$this->user->hasPermission('access', $rota)) {
				return new Action('sistem/403');
			}
		}
	}
}
