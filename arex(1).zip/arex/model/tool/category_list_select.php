<?php
class ModelToolCategorylistselect extends Model {
	public function kategori_listele($kategori_id=0, $onek=0) {
		$klist = "";
		$kategori_listele = $this->db->query("select * from kategoriler where parent='".$kategori_id."' order by sira asc");
		foreach ($kategori_listele->rows as $val) {
			$langs = json_decode($val['langs'], true);
			if ($kategori_id==$val['id']) {
			    $onay = 'selected';
			} else {
			    $onay = '';
			}	
			$ekle=str_repeat('-', $onek);
			$klist .= "<option value='".$val['id']."' ".$onay.">".$ekle." ".$langs[$this->session->data['lang']]."</option>";
			$klist .= $this->kategori_listele($val['id'], $onek+2);
		}
		return $klist;
	}
	public function lang_array($langs=array()) {
		$data = array();
		foreach (lang_array() as $key => $value) {
			$lng = array(
				'img' => "view/image/".$key.".png", 
				'lang' => $key,
				'upper' => strtoupper($key),
				'adi' => $value,
				'langs' => isset($langs[$key]) ? $langs[$key] : "",
			);
			$data[] = $lng;
		}
		return $data;
	}	
	public function icerik_array($langs=array()) {
		$data = array();
		foreach (lang_array() as $key => $value) {
			$lng = array(
				'img' => "view/image/".$key.".png", 
				'lang' => $key,
				'upper' => strtoupper($key),
				'adi' => $value,
				'langs' => base64_decode(isset($langs[$key]) ? $langs[$key] : ""),
			);
			$data[] = $lng;
		}
		return $data;
	}
	public function parent_bul($val){
		$kategori_listele = $this->db->query("select * from kategoriler where id='".$val."'");
		$resp = "";
		if ($kategori_listele->num_rows > 0) {
			if ($kategori_listele->row['parent']!=0) {
				$resp .= $this->parent_bul($kategori_listele->row['parent']);
			}
			$langs = json_decode(json_suz($kategori_listele->row['langs']), true);
			$resp .= "<a href='category/".$kategori_listele->row['id']."'>".$langs[$this->session->data['lang']]."</a><span class='breadcrumbs_sep'><span></span></span>";
			return $resp;
		}
	}
	public function cat_breadcrumbs($kid=0) {
		 $kategori_listele = $this->db->query("select * from kategoriler where id='".$kid."' order by sira asc");
		 $resp = "";
		 foreach ($kategori_listele->rows as $val) {
		 	$langs = json_decode(json_suz($val['langs']), true);
		 	if ($val['parent']!=0) {
		 		$resp .= $this->parent_bul($val['parent']);
		 	}
		 }
		 $resp .= "<span>".$langs[$this->session->data['lang']]."</span>";
        return $resp;
	}	
	public function page_breadcrumbs($kid=0) {
		 $kategori_listele = $this->db->query("select * from kategoriler where id='".$kid."' order by sira asc");
		 $resp = "";
		 foreach ($kategori_listele->rows as $val) {
		 	$langs = json_decode(json_suz($val['langs']), true);
		 	if ($val['parent']!=0) {
		 		$resp .= $this->parent_bul($val['parent']);
		 	}
		 }
		 $resp .= "<a href='category/".$kid."'>".$langs[$this->session->data['lang']]."</a><span class='breadcrumbs_sep'><span></span></span>";
        return $resp;
	}		
}
