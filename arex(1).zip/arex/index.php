<?php
//header("location:/count/image.html");
if (is_file('system/config.php')) {
	require_once('system/config.php');
}
require_once(DIR_SYSTEM . 'startup.php');
start('admin');